//
//  CouponListCell.swift
//  token
//
//  Created by 王瀚 on 2019/7/25.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class CouponListCell: UITableViewCell{
    var couponValue: Int = 0
    var couponPreview:UIImageView? = nil
    var couponName:UILabel? = nil
    var couponDeadLine:UILabel? = nil
    var couponListIdentifier:Int = 0
    var url: String? = ""
    var authCode: String? = ""
    var id : String!
    var intterView : UIView!
    var dashLine : UILabel!
    var used : Int!
    var onClickTrigger : UIButton!
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        intterView = UIView(frame: CGRect(x: viewLeftLine, y: 0, width: Int(fullViewSize.width), height: 140))
        //frame = CGRect(x: viewLeftLine, y: 0, width: Int(fullViewSize.width), height: 140)
        backgroundColor = .clear
        intterView.backgroundColor = .invertMain
        intterView.addShadow(radius: CGFloat(10), opacity: 0.1)
        intterView.norm()
        self.addSubview(intterView)
        
        dashLine = UILabel(frame:CGRect(
            x: 0, y: 0, width: (fullViewSize.width) - 20, height: 120))
        dashLine.center = CGPoint(x: (fullViewSize.width) / 2, y: CGFloat(70))
        dashLine.backgroundColor = .clear
        dashLine.addDashBorder(color: UIColor.gray)
        intterView.addSubview(dashLine)
        
        couponPreview = UIImageView(frame: CGRect(x: gutter.height + 10, y: gutter.height + 10, width: (dashLine.frame.height - gutter.height * 2) * 1.2, height: dashLine.frame.height - gutter.height * 2))
        
        couponPreview!.downloaded(from: "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg", contentMode: .scaleAspectFill)
        
        couponPreview!.clipsToBounds = true
        intterView.addSubview(couponPreview!)
        
        couponName = UILabel(frame: CGRect(x: 0, y: 0, width: dashLine.frame.width - couponPreview!.frame.width - gutter.width * 3, height: 20))
        couponName!.font = .medi
        couponName!.textColor = .black
        couponName!.frame.origin = CGPoint(x: couponPreview!.frame.origin.x + couponPreview!.frame.width + gutter.width, y: (dashLine.frame.height - 60 - gutter.height + 20) / 2)
        intterView.addSubview(couponName!)
        
        couponDeadLine = UILabel(frame: CGRect(x: 0, y: 0, width: dashLine.frame.width - couponPreview!.frame.width - gutter.width * 3, height: 40))
        couponDeadLine!.font = .norm
        couponDeadLine!.numberOfLines = 2
        couponDeadLine!.textColor = .gray
        couponDeadLine!.frame.origin = CGPoint(x: couponPreview!.frame.origin.x + couponPreview!.frame.width + gutter.width, y: couponName!.frame.origin.y + couponName!.frame.height + gutter.height)
        intterView.addSubview(couponDeadLine!)
        
        onClickTrigger = UIButton(frame: CGRect(x: 0, y: 0, width: intterView.frame.width, height: intterView.frame.height))
        onClickTrigger.backgroundColor = .clear
        onClickTrigger.isUserInteractionEnabled = true
        onClickTrigger.addTarget(self, action: #selector(onClick), for: .touchUpInside)
        intterView.addSubview(onClickTrigger)
                
        norm()
    }
    
    @objc func onClick(){
        if(couponListIdentifier == 1){
            var topController = UIApplication.shared.keyWindow?.rootViewController
            while ((topController?.presentedViewController) != nil) {
                topController = topController?.presentedViewController;
            }
            print(self.couponValue, self.couponName!.text!, "!!!!!!!")
            CouponDetailViewController().modalPresentationStyle = UIModalPresentationStyle.custom
            let tac = CouponDetailViewController()
            tac.price = self.couponValue
            tac.name = self.couponName!.text!
            tac.couponID = self.id
            topController?.present(tac, animated: true, completion: nil)
        }
        else if (couponName!.text! != "您目前沒有優惠券喔" && used != 1){
            var topController = UIApplication.shared.keyWindow?.rootViewController
            while ((topController?.presentedViewController) != nil) {
                topController = topController?.presentedViewController;
            }
            CouponDetailViewController().modalPresentationStyle = UIModalPresentationStyle.custom
            UsingOwnCouponViewController.shared.showOverlay(authCode: self.authCode!, name: self.couponName!.text!, url: self.url!, id: self.id!)
            
        }
    }
    @objc func test(){
        print(couponName)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
