//
//  MainButton.swift
//  token
//
//  Created by 王瀚 on 2019/7/21.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit

class MainButton: UIButton, CAAnimationDelegate{
    
    var mainColor:UIColor = .main
    required init() {
        let frame = CGRect(x: 0, y: 0, width: fullViewSize.width, height: 48)
        super.init(frame: frame)
        setup()
    }
    
    required init(inline: Int) {
        let gutt = Int(gutter.width)
        let shift = gutt*(inline-1)
        let frame = CGRect(x: 0, y: 0, width: (fullViewSize.width-CGFloat(shift)) / CGFloat(inline), height: 48)
        super.init(frame: frame)
        setup()
    }
    
    required init(width: Int) {
        let frame = CGRect(x: 0, y: 0, width: width, height: 48)
        super.init(frame: frame)
        setup()
    }
    
    func setup() {
        backgroundColor = mainColor
        setTitleColor(.white, for: .normal)
        layer.cornerRadius = CGFloat(cornerRadius)
        self.clipsToBounds = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        let touch = touches.first
        
        let location = touch?.location(in: self);
        if(location != nil)
        {
            let smallerSize = min(self.frame.width, self.frame.height)
            let longgerSize = max(self.frame.width, self.frame.height)
            let scale = longgerSize / smallerSize + 0.5
            let radius = smallerSize / 2
            let rect = CGRect(x: 0, y: 0, width: radius*2, height: radius*2)
            let layer = CAShapeLayer()
            layer.lineWidth = 1
            layer.position = location!
            layer.path = UIBezierPath(roundedRect: rect, cornerRadius: radius).cgPath
            layer.fillColor = self.backgroundColor?.lighter()?.cgColor
            layer.bounds = CGRect(x: 0, y: 0, width: radius*2, height: radius*2)
            let group = animateGroup(scale: scale)
            self.layer.insertSublayer(layer, at: 0)
            group.setValue(layer, forKey: "animatedLayer")
            layer.add(group, forKey: "buttonAnimation")
        }
    }
    
    private func animateGroup(scale: CGFloat) -> CAAnimationGroup {
        let opacityAnim = CABasicAnimation(keyPath: "opacity")
        opacityAnim.fromValue = NSNumber(value: 1)
        opacityAnim.toValue = NSNumber(value: 0)
        
        let scaleAnim = CABasicAnimation(keyPath: "transform")
        scaleAnim.fromValue = NSValue(caTransform3D: CATransform3DIdentity)
        scaleAnim.toValue = NSValue(caTransform3D: CATransform3DMakeScale(scale, scale, scale))
        
        let group = CAAnimationGroup()
        group.animations = [opacityAnim, scaleAnim]
        group.duration = 0.5
        group.delegate = self as! CAAnimationDelegate
        group.fillMode = CAMediaTimingFillMode.both
        group.isRemovedOnCompletion = false
        return group
    }
    
    
    
}
