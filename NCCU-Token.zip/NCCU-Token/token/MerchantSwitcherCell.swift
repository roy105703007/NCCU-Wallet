//
//  MerchantSwitcherCell.swift
//  token
//
//  Created by 王瀚 on 2019/7/28.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class MerchantSwitcherCell: UICollectionViewCell {
    let itemTitle = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        // 建立一個 UILabel
       
        itemTitle.font = .norm
        itemTitle.sizeToFit()
        itemTitle.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.height)
        itemTitle.textAlignment = .center
        itemTitle.layer.borderWidth = 1
        itemTitle.layer.borderColor = UIColor.main.cgColor
        itemTitle.layer.cornerRadius = frame.height / 2
        itemTitle.backgroundColor = .clear
        itemTitle.textColor = .main
        self.addSubview(itemTitle)
        norm()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
