//
//  CouponHeaderView.swift
//  token
//
//  Created by 王瀚 on 2019/7/23.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class CouponHeaderView: UIView{
    let couponHeaderContent = UIView()
    let couponSegControl = CouponSegmentedControl()
    var dele:CouponSegmentContainerDelegate?
    let balanceLabel = UILabel()
    let balanceNum = UILabel()
    override init(frame: CGRect) {
        let layout = frame
        super.init(frame: layout)
        couponHeaderContent.frame = layout
        setup()
    }
    func setup(){
        couponHeaderContent.backgroundColor = .invertMain
        couponHeaderContent.clipsToBounds = true
        frame.origin = CGPoint(x: 0, y: 0)
        clipsToBounds = false
        addSubview(couponHeaderContent)
        roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: couponHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        
        balanceLabel.frame = CGRect(x: viewLeftLine + Int(gutter.width), y: Int(statusBarHeight) + Int(between.height) - (UIDevice.hasNotch ? 15 : 10), width: 100, height: 40)
        balanceLabel.font = .norm
        balanceLabel.textColor = .gray
        balanceLabel.text = lang["mybalance"]
        couponHeaderContent.addSubview(balanceLabel)
        
        balanceNum.frame = CGRect(x: 0, y: 0, width: fullViewSize.width - gutter.width * 2 - balanceLabel.frame.width, height: 40)
        balanceNum.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .main),("   pt", UIFont.medi, .lightBlue)])
        balanceNum.textAlignment = .right
        balanceNum.frame.origin = CGPoint(x: viewRightLine - gutter.width - balanceNum.frame.width, y: statusBarHeight + between.height - (UIDevice.hasNotch ? 15 : 10))
        couponHeaderContent.addSubview(balanceNum)
        couponSegControl.addTarget(self, action: #selector(onSegChange), for: .valueChanged)
        couponHeaderContent.addSubview(couponSegControl)
        norm()
        couponHeaderContent.norm()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func onSegChange(sender: UISegmentedControl){
        self.dele?.switchTab(to: sender.selectedSegmentIndex)
    }
}
