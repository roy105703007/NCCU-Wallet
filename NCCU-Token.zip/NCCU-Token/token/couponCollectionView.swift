//
//  couponCollectionView.swift
//  token
//
//  Created by 王瀚 on 2019/7/23.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class couponCollectionView: UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate{
    let dataSet = ["1","2","3","4","5"]
    var data = [["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100]]
    init() {
        let willExpCouponListLayout = couponCollectionViewLayout()
        //willExpCouponListLayout.sectionInset = UIEdgeInsets(top: 0, left: CGFloat(viewLeftLine), bottom: 0, right: 0)
        willExpCouponListLayout.itemSize = CGSize(width: (fullViewSize.width - 4 * gutter.width + CGFloat(viewLeftLine)), height: 140)
        willExpCouponListLayout.minimumLineSpacing = gutter.width
        willExpCouponListLayout.scrollDirection = .horizontal
        //willExpCouponListLayout.sectionInset = UIEdgeInsets(top: 0, left: -gutter.width/2, bottom: 0, right: -gutter.width/2)
        super.init(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 140), collectionViewLayout: willExpCouponListLayout)
        backgroundColor = .clear
        decelerationRate = UIScrollView.DecelerationRate.fast
        bounces = false
        clipsToBounds = false
        showsHorizontalScrollIndicator = false
        contentInset = UIEdgeInsets(top: 0, left: CGFloat(viewLeftLine), bottom: 0, right: 4 * gutter.width + CGFloat(viewLeftLine))
        register(couponCollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        delegate = self
        dataSource = self
        getCouponInfo()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! couponCollectionViewCell
        //cel.titleLabel.text = "\(indexPath.item + 1)"
        //return cel
        //cell.accessoryType = .none
        cell.couponPreview!.downloaded(from: data[indexPath.row]["image"] as? String ?? "", contentMode: .scaleAspectFill)
        cell.couponName!.text = data[indexPath.row]["name"] as? String ?? ""
        cell.authCode = data[indexPath.row]["authCode"] as? String ?? ""
        cell.url = data[indexPath.row]["url"] as? String ?? ""
        cell.id = data[indexPath.row]["_id"] as? String ?? ""

        let showedExpiredDate = dateAddSymbol(date: data[indexPath.row]["deadline"] as! Int)
        cell.couponDeadLine!.text = "到期日\n\(showedExpiredDate)"
        
        return cell
    }
    func dateAddSymbol(date: Int) -> String{
        var str = String(date)
        str.insert("/", at: str.index(str.startIndex, offsetBy: 4))
        str.insert("/", at: str.index(str.startIndex, offsetBy: 7))
        str.insert(" ", at: str.index(str.startIndex, offsetBy: 10))
        str.insert(":", at: str.index(str.startIndex, offsetBy: 13))
        str.insert(":", at: str.index(str.startIndex, offsetBy: 16))
        
        return str
    }
    func getCouponInfo(){
        self.data = []
        if(myCouponsResults.count != 0){
            for i in myCouponsResults!{
                if(self.data.count >= 5){
                    break
                }
                var dict1: [String:Any] = [:]
                dict1["url"] = i.url
                dict1["name"] = i.product
                dict1["deadline"] = Int(i.expiredDate)
                dict1["image"] = "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg"
                dict1["authCode"] = i.authCode
                dict1["_id"] = i.id
                if(i.used == false){
                    self.data.append(dict1)
                }
            }
            self.data = self.data.sorted(by: { ($0["deadline"] as! Int) < ($1["deadline"] as! Int) })

        }
        else if(myCouponsResults.count == 0){
            var dict1: [String:Any] = [:]
            dict1["_id"] = "fffffff"
            dict1["name"] = "您目前沒有優惠券喔"
            dict1["deadline"] = ""
            dict1["image"] = "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg"
            //dict1["value"] = i.product.point
            dict1["authCode"] = ""
            dict1["url"] = ""
            self.data.append(dict1)
        }
        
    }
}
