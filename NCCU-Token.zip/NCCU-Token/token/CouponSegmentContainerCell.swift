//
//  CouponSegmentContainerCell.swift
//  token
//
//  Created by 王瀚 on 2019/7/24.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class couponSegmentContainerCell: UICollectionViewCell {
    override init(frame: CGRect) {
        super.init(frame: frame)
        norm()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
