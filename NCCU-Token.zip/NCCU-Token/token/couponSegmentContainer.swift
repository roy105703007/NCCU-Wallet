//
//  couponSegmentContainer.swift
//  token
//
//  Created by 王瀚 on 2019/7/24.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
protocol scrollDetetor{
    func couponListScroll(_ scrollView: UIScrollView, from: Int)
}
class CouponSegmentContainer: UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate, scrollDetetor{
    var dele:CouponSegmentContainerDelegate?
    var myCouponView:MyCouponView? = nil
    var exchangeCouponView:ExchangeCouponView? = nil
    var currentIndex = 0
    init(frame: CGRect) {
        let couponSegmentContainerLayout = UICollectionViewFlowLayout()
        couponSegmentContainerLayout.itemSize = CGSize(width: frame.size.width, height: frame.size.height)
        couponSegmentContainerLayout.scrollDirection = .horizontal
        couponSegmentContainerLayout.minimumLineSpacing = 0
        super.init(frame: frame, collectionViewLayout: couponSegmentContainerLayout)
        myCouponView = MyCouponView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        myCouponView!.couponList!.dele = self
        exchangeCouponView = ExchangeCouponView(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        exchangeCouponView!.exchangeCouponList!.dele = self
        backgroundColor = .clear
        isPagingEnabled = true
        decelerationRate = UIScrollView.DecelerationRate.fast
        bounces = false
        showsHorizontalScrollIndicator = false
        register(couponSegmentContainerCell.self, forCellWithReuseIdentifier: "couponSegCell")
        delegate = self
        dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        self.dele?.startChanging(scrollView)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let x = scrollView.contentOffset.x / fullScreenSize.width
        self.dele?.pageChaging(per: x)
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let x = scrollView.contentOffset.x
        let w = scrollView.bounds.size.width
        let currentPage = Int(ceil(x/w))
        self.dele?.onPageChange(currentPage: currentPage)
        currentIndex = currentPage
        //self.dele?.onPageChange(currentPage: currentPage)
    }
    func switchToPage(to: Int){
        currentIndex = to
        scrollToItem(at: IndexPath(item: to, section: 0), at: (to == 0) ? .right : .left, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cel = collectionView.dequeueReusableCell(withReuseIdentifier: "couponSegCell", for: indexPath) as! couponSegmentContainerCell
        //cel.titleLabel.text = "\(indexPath.item + 1)"
        if(indexPath.row == 0){
            cel.addSubview(myCouponView!)
        }else{
            cel.addSubview(exchangeCouponView!)
        }
        return cel
    }
    func couponListScroll(_ scrollView: UIScrollView, from: Int){
        self.dele?.couponListScroll(scrollView, from: from)
    }
}
