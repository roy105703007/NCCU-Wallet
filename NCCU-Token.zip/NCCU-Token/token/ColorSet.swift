//
//  ColorSet.swift
//  token
//
//  Created by 王瀚 on 2019/7/21.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    static var main: UIColor {
        return UIColor(red:0.08, green:0.27, blue:0.48, alpha:1.0).modified()
    }
    static var invertMain: UIColor{
        return UIColor(red:1.00, green:1.00, blue:1.00, alpha:1.0)
    }
    static var lightBlue: UIColor {
        // define your color here
        return UIColor(red:0.47, green:0.90, blue:0.91, alpha:1.0).modified()
    }
    static var lightBlueDarken: UIColor {
        // define your color here
        return UIColor(red:0.35, green:0.86, blue:0.87, alpha:1.0).modified()
    }
    static var darkRed: UIColor {
        // define your color here
        return UIColor(red:0.84, green:0.24, blue:0.53, alpha:1.0).modified()
    }
    static var lightYellow: UIColor {
        return UIColor(red:0.92, green:0.92, blue:0.46, alpha:1.0).modified()
    }
    static var bgColor: UIColor {
        return UIColor(red:1.00, green:1.00, blue:1.00, alpha:1.0)
    }
    static var inputBG: UIColor {
        return UIColor(red:0.95, green:0.95, blue:0.95, alpha:1.0)
    }
    func modified() -> UIColor {
        var currentHue: CGFloat = 0.0
        var currentSaturation: CGFloat = 0.0
        var currentBrigthness: CGFloat = 0.0
        var currentAlpha: CGFloat = 0.0
        let additionalSaturation = CGFloat(0.3)
        if self.getHue(&currentHue, saturation: &currentSaturation, brightness: &currentBrigthness, alpha: &currentAlpha){
            return UIColor(hue: currentHue,
                           saturation: currentSaturation + additionalSaturation,
                           brightness: currentBrigthness,
                           alpha: currentAlpha)
        } else {
            return self
        }
    }
}
