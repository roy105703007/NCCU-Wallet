//
//  FilterModal.swift
//  token
//
//  Created by 王瀚 on 2019/7/28.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

var overlayView = UIVisualEffectView()

struct TagResult: Codable {
    var status: Bool
    var tags: [String]
}
public class FilterModal{
    var tagResults : TagResult?
    var overlayView = UIVisualEffectView()
    var filterModalLayer = UIView()
    var merchantList = Set<String>()
    var avaMerchanList = [String]()
    var priceRange:[Int]!
    var confirmFilter = MainButton()
    var merchantSwitcher = MerchantSwitcher()
    var valueSlider : RangeSeekSlider!
    let apiGroup = DispatchGroup()
    let forGroup = DispatchGroup()
    let forGroup2 = DispatchGroup()

    var delegate: GetFilterDetailDelegate!
    class var shared: FilterModal {
        struct Static {
            static let instance: FilterModal = FilterModal()
        }
        return Static.instance
    }
    
    public func showOverlay(range: [Int], dele: GetFilterDetailDelegate) {
        if  let appDelegate = UIApplication.shared.delegate as? AppDelegate, let window = appDelegate.window {
            overlayView.frame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height)
            overlayView.backgroundColor = .clear
            overlayView.clipsToBounds = true
            window.addSubview(overlayView)
            
            self.delegate = dele
            
            let closeTriger = UIButton(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height))
            closeTriger.addTarget(self, action:  #selector(self.hideOverlayView), for: .touchUpInside)
            overlayView.contentView.addSubview(closeTriger)
            
            let filterModalContent = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 410))
            filterModalLayer.frame = CGRect(x: 0, y: fullScreenSize.height, width: fullScreenSize.width, height: 410)
            filterModalLayer.roundCorners(corners: [.topLeft,.topRight], radius: 10, content: filterModalContent, shadowRadius: 2, shadowOpacity: 0.15)
            filterModalLayer.norm()
            filterModalContent.backgroundColor = .invertMain
            filterModalLayer.addSubview(filterModalContent)
            overlayView.contentView.addSubview(filterModalLayer)
            
            let filterModalTitle = UILabel(frame: CGRect(x: between.width, y: between.height, width: fullScreenSize.width - 2*between.width - 50, height: 60))
            filterModalTitle.numberOfLines = 2
            filterModalTitle.multiStyle(content: [(lang["filterCoupons"]!, UIFont.mediBold, UIColor.main),("\n\(lang["filterCouponsHint"]!)", UIFont.norm, UIColor.gray)])
            filterModalTitle.sizeToFit()
            filterModalContent.addSubview(filterModalTitle)
            
            let merchantSwitcherTitle = UILabel(frame: CGRect(x: between.width, y: filterModalTitle.frame.origin.y + filterModalTitle.frame.height + between.height, width: fullScreenSize.width - 2*between.width - 50, height: 15))
            merchantSwitcherTitle.font = .norm
            merchantSwitcherTitle.text = lang["merchantRange"]
            filterModalContent.addSubview(merchantSwitcherTitle)
            apiGroup.enter()
            Alamofire.request(serverIP + "/coupon/tag", method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                if let apiResult: NSDictionary = (response.result.value as! NSDictionary) {
                    self.merchantSwitcher = MerchantSwitcher()
                    let result = apiResult["tags"] as! [String]
                    self.merchantSwitcher.dataSet = result
                    self.merchantSwitcher.selected = [result[0]]
                }
                else {
                    print("error")
                }
                self.apiGroup.leave()
            }
            apiGroup.notify(queue: DispatchQueue.main, execute: {
                self.forGroup.enter()
                self.merchantSwitcher.reloadData()
                self.forGroup.leave()
                self.forGroup.notify(queue: DispatchQueue.main, execute: {
                    self.merchantSwitcher.layoutIfNeeded()
                    for item in self.merchantSwitcher.selected{
                        self.forGroup2.enter()
                        if let ind = self.merchantSwitcher.dataSet.firstIndex(of: item){
                            self.merchantSwitcher.selectItem(at: IndexPath(row: ind, section: 0) , animated: false, scrollPosition: UICollectionView.ScrollPosition.left)
                            self.forGroup2.leave()
                        }
                    }
                    self.forGroup2.notify(queue: DispatchQueue.main, execute: {
                        self.merchantSwitcher.frame.origin = CGPoint(x: 0, y: merchantSwitcherTitle.frame.origin.y + merchantSwitcherTitle.frame.height + gutter.height)
                        filterModalContent.addSubview(self.merchantSwitcher)
                        
                        
                        let valueSliderTitle = UILabel(frame: CGRect(x: between.width, y: self.merchantSwitcher.frame.origin.y + self.merchantSwitcher.frame.height + between.height, width: fullScreenSize.width - 2*between.width - 50, height: 15))
                        valueSliderTitle.font = .norm
                        valueSliderTitle.text = lang["valueRange"]
                        filterModalContent.addSubview(valueSliderTitle)
                        
                        self.valueSlider = RangeSeekSlider(frame: CGRect(x: CGFloat(viewLeftLine), y: valueSliderTitle.frame.origin.y + valueSliderTitle.frame.height + gutter.height, width: fullViewSize.width, height: 50))
                        self.valueSlider.colorBetweenHandles = .lightBlue
                        self.valueSlider.minValue = CGFloat(range[0])
                        self.valueSlider.maxValue = CGFloat(range[1])
                        self.valueSlider.selectedMaxValue = self.valueSlider.maxValue * 0.8
                        self.valueSlider.handleColor = .invertMain
                        self.valueSlider.minLabelColor = .main
                        self.valueSlider.maxLabelColor = .main
                        self.valueSlider.handleDiameter = 28
                        self.valueSlider.selectedHandleDiameterMultiplier = 1.0
                        filterModalContent.addSubview(self.valueSlider)
                        
                        self.confirmFilter.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: 410 - self.confirmFilter.frame.height - between.height)
                        self.confirmFilter.setTitle(lang["confirmFilter"],for: UIControl.State.normal)
                        self.confirmFilter.addTarget(self, action:  #selector(self.confirm), for: .touchUpInside)
                        filterModalContent.addSubview(self.confirmFilter)
                        
                        UIView.animate(withDuration: 0.5) {
                            self.overlayView.effect = UIBlurEffect(style: UIBlurEffect.Style.light)
                        }
                        
                        UIView.animate(withDuration: 0.3, delay: 0.3, options: .curveEaseInOut, animations: {
                            self.filterModalLayer.frame.origin.y = fullScreenSize.height - 410
                        })
                    })
                })
            })
        }
        
    }
    
    @objc public func hideOverlayView() {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
            self.filterModalLayer.frame.origin.y = fullScreenSize.height
        })
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseInOut, animations: {
            self.overlayView.effect = nil
        },completion: { (finished: Bool) in
            self.overlayView.removeFromSuperview()
        })
    }
    @objc public func confirm() {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
            self.filterModalLayer.frame.origin.y = fullScreenSize.height
        })
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseInOut, animations: {
            self.overlayView.effect = nil
        },completion: { (finished: Bool) in
            self.overlayView.removeFromSuperview()
            self.delegate.getDetail(selected: self.merchantSwitcher.getSelected() ,range: [Int(self.valueSlider!.selectedMinValue), Int(self.valueSlider!.selectedMaxValue)])
        })
    }
}
