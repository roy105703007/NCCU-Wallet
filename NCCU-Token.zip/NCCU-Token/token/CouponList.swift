//
//  CouponList.swift
//  token
//
//  Created by 王瀚 on 2019/7/25.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class CouponList: UITableView, UITableViewDelegate, UITableViewDataSource{
    var dele:scrollDetetor?
    var data = [["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100],["name": "i禮贈100元即享券", "deadline": "2019/07/12", "image": "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg","value": 100]]
    var showValue = false
    var range = [1000000, 0]
    var couponListIdentifier = 0
    var filter = false
    init(frame: CGRect) {
        let cellHeight = 155
        super.init(frame: frame, style: .plain)
        getCouponInfo()
        rowHeight = CGFloat(cellHeight)
        estimatedRowHeight = 0
        register(CouponListCell.self, forCellReuseIdentifier: "mcCell")
        delegate = self
        dataSource = self
        separatorStyle = .none
        allowsSelection = false
        //separatorInset = UIEdgeInsets(top: 0, left: gutter.width, bottom: gutter.height, right: gutter.width)
        contentInset = UIEdgeInsets(top: between.height, left: 0, bottom: between.height, right: 0)
        contentSize = CGSize(width: fullScreenSize.width, height: CGFloat(data.count * 155) + CGFloat(between.height * 2))
        allowsSelection = false
        norm()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mcCell", for: indexPath as IndexPath) as! CouponListCell
        // 設置 Accessory 按鈕樣式

        cell.accessoryType = .none
        cell.couponPreview!.downloaded(from: data[indexPath.row]["image"] as? String ?? "", contentMode: .scaleAspectFill)
        cell.couponName!.text = data[indexPath.row]["name"] as? String ?? ""
        cell.id = data[indexPath.row]["_id"] as! String
        if(showValue){   //exchange coupon
            if let val:Int=data[indexPath.row]["value"] as? Int{
                cell.couponDeadLine!.multiStyle(content: [("\(String(val)) pt\n", .normSemiBold, .main),(data[indexPath.row]["deadline"] as? String ?? "", .norm, .gray)])
                cell.couponValue = val
                if(val > range[1]){
                    range[1] = val
                }
                if(val < range[0]){
                    range[0] = val
                }
            }else{
                cell.couponDeadLine!.text = "\n\(data[indexPath.row]["deadline"] as? String ?? "")"
                cell.couponValue = 0

            }
        }else{   //my coupon
            let showedExpiredDate = dateAddSymbol(date: data[indexPath.row]["deadline"] as! Int)
            cell.couponDeadLine!.text = "到期日\n\(showedExpiredDate)"
            cell.authCode = data[indexPath.row]["authCode"] as! String
            cell.url = data[indexPath.row]["url"] as! String
            cell.used = data[indexPath.row]["used"] as! Int

            if(data[indexPath.row]["used"] as! Int == 1){
                cell.onClickTrigger.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.9)
            }
            else{
                cell.onClickTrigger.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0)
            }
        }
        cell.couponListIdentifier = couponListIdentifier
        cell.selectionStyle = UITableViewCell.SelectionStyle.none
        if(indexPath.row == data.count - 1){
            filter = false
        }
        return cell
    }
    func dateAddSymbol(date: Int) -> String{
        var str = String(date)
        str.insert("/", at: str.index(str.startIndex, offsetBy: 4))
        str.insert("/", at: str.index(str.startIndex, offsetBy: 7))
        str.insert(" ", at: str.index(str.startIndex, offsetBy: 10))
        str.insert(":", at: str.index(str.startIndex, offsetBy: 13))
        str.insert(":", at: str.index(str.startIndex, offsetBy: 16))

        return str
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.dele?.couponListScroll(scrollView, from: couponListIdentifier)
    }
    func getRange() -> [Int]{
        return self.range
    }
    func filterData(selected: [String], range: [Int]){
        self.data = []
        self.filter = true
        for i in couponsResults!.coupons{
            for j in selected {
                if(i.product.name.contains(j) && i.product.point >= range[0] && i.product.point <= range[1] && i.count > 0){
                    var dict1: [String:Any] = [:]
                    dict1["_id"] = i.product._id
                    dict1["name"] = i.product.name
                    dict1["deadline"] = "2019/07/12"
                    dict1["image"] = "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg"
                    dict1["value"] = i.product.point
                    self.data.append(dict1)
                }
            }
        }
        self.reloadData()
    }
    func getCouponInfo(){
        self.data = []
        if(self.couponListIdentifier == 1){
            for i in couponsResults!.coupons{
                if(i.count > 0){
                    var dict1: [String:Any] = [:]
                    dict1["_id"] = i.product._id
                    dict1["name"] = i.product.name
                    dict1["deadline"] = "2019/07/12"
                    dict1["image"] = "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg"
                    dict1["value"] = i.product.point
                    self.data.append(dict1)
                }
            }
        }
        else{
            if(myCouponsResults.count != 0){
                for i in myCouponsResults!{
                    var dict1: [String:Any] = [:]
                    dict1["_id"] = i.id
                    dict1["name"] = i.product
                    dict1["deadline"] = Int(i.expiredDate)
                    dict1["image"] = "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg"
                        //dict1["value"] = i.product.point
                    dict1["authCode"] = i.authCode
                    dict1["url"] = i.url
                    dict1["used"] = Int(NSNumber(value: i.used))
                    self.data.append(dict1)
                    print(dict1["deadline"])
                }
                self.data = self.data.sorted(by: { ($0["deadline"] as! Int) < ($1["deadline"] as! Int) })
                self.data = self.data.sorted(by: { ($0["used"] as! Int) < ($1["used"] as! Int) })
            }
            else if(myCouponsResults.count == 0){
                var dict1: [String:Any] = [:]
                dict1["_id"] = "id"
                dict1["name"] = "您目前沒有優惠券喔"
                dict1["deadline"] = ""
                dict1["image"] = "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg"
                //dict1["value"] = i.product.point
                dict1["authCode"] = ""
                dict1["url"] = ""
                self.data.append(dict1)
            }
        }
        self.reloadData()
    }
}
