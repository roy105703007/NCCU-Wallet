//
//  LastestTransactionTableViewCell.swift
//  token
//
//  Created by 王瀚 on 2019/7/23.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class LastestTransactionTableViewCell: UITableViewCell{
    let logIcon = UIImageView()
    let logTitle = UILabel()
    let logContent = UILabel()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        frame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 76)
        logIcon.frame = CGRect(x: 14, y: 19.5, width: 37, height: 37)
        logIcon.contentMode = .scaleAspectFit
        addSubview(logIcon)
        
        logTitle.frame = CGRect(x: 14 + logIcon.frame.width + gutter.width, y: 10, width: (fullScreenSize.width - 20 - 32 - logIcon.frame.width - gutter.width), height: 22)
        logTitle.font = .medi
        logTitle.textColor = .black
        addSubview(logTitle)
        
        logContent.numberOfLines = 2
        logContent.frame = CGRect(x: 14 + logIcon.frame.width + gutter.width, y: logTitle.frame.origin.y + logTitle.frame.height, width: (fullScreenSize.width - 20 - 32 - logIcon.frame.width - gutter.width), height: 40)
        logContent.font = .norm
        logContent.textColor = .gray
        addSubview(logContent)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
