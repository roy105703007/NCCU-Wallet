//
//  TopDownSegue.swift
//  token
//
//  Created by 王瀚 on 2019/8/5.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class TopDownSegue: UIStoryboardSegue {
    let duration: TimeInterval = 0.3
    let delay: TimeInterval = 0
    let animationOptions: UIView.AnimationOptions = .curveEaseIn
    
    override func perform() {
        // get views
        guard let sourceView = source.view else { return }
        let destinationView = destination.view
        
        // get screen height
        let screenHeight = UIScreen.main.bounds.size.height
        //sourceView.transform = CGAffineTransform(translationX: 0, y: 0)
        
        // add destination view to view hierarchy
        UIApplication.shared.keyWindow?.insertSubview(destinationView!, at: 0)
        
        // animate
        UIView.animate(withDuration: duration, delay: delay, options: animationOptions, animations: {
            sourceView.frame.origin = CGPoint(x: 0, y: screenHeight)
        }) { (_) in
            self.source.present(self.destination, animated: false, completion: nil)
        }
    }
}
