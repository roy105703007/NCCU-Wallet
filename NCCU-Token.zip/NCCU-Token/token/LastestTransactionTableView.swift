//
//  LastestTransactionTableView.swift
//  token
//
//  Created by 王瀚 on 2019/7/23.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Alamofire
import Foundation
import UIKit
class LastestTransactionTableView: UITableView, UITableViewDelegate, UITableViewDataSource{
    var info = [["type":"transaction","content":"您已於2019/07/10 10:30am 轉出100 pt."],["type":"income","content":"您於2019/07/10 10:30am 獲得150 pt."],["type":"income","content":"您於2019/07/10 10:30am 獲得150 pt."],["type":"income","content":"您於2019/07/10 10:30am 獲得150 pt."],["type":"transaction","content":"您已於2019/07/10 10:30am 轉出100 pt."],["type":"transaction","content":"您已於2019/07/10 10:30am 轉出100 pt."]]
    init() {
        let cellHeight = 76
        super.init(frame: CGRect(x: 0, y: 0, width: Int(fullScreenSize.width), height: info.count * (cellHeight)), style: .plain)
        getInfo()
        rowHeight = CGFloat(cellHeight)
        estimatedRowHeight = 0
        register(LastestTransactionTableViewCell.self, forCellReuseIdentifier: "ltCell")
        delegate = self
        dataSource = self
        separatorStyle = .singleLine
        separatorInset = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 0)
        allowsSelection = false
        isScrollEnabled = false
    
      
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return info.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ltCell", for: indexPath as IndexPath) as! LastestTransactionTableViewCell
            // 設置 Accessory 按鈕樣式
        
            cell.accessoryType = .disclosureIndicator
            cell.logIcon.image = UIImage.colorful(named: info[indexPath.row]["type"]!)
            cell.logTitle.text = lang["\(info[indexPath.row]["type"]!)-ovLog"]
            cell.logContent.text = info[indexPath.row]["content"]!
            cell.logContent.sizeToFit()
            return cell
    }
    
    func getInfo(){
        print("test now")
        self.info = []
        var countLog = 0
        for i in logResults!.tx_logs{
            countLog += 1
            if countLog >= 11 {
                break
            }
            var dict1: [String:String] = [:]
            if i.from_account.name == user.name {
                print("out")
                var dateString = ""
                var dicString = i.create_date.split(separator: "T")
                var dicString2 = dicString[1].split(separator: ".")
                dateString = dicString[0] + " " + dicString2[0]
                dict1["type"] = "transaction"
                dict1["content"] = "您已於" + dateString + "轉出" + String(i.point) + " pt."
                self.info.append(dict1)
            }
            else {
                print("in")
                var dateString = ""
                var dicString = i.create_date.split(separator: "T")
                var dicString2 = dicString[1].split(separator: ".")
                dateString = dicString[0] + " " + dicString2[0]
                dict1["type"] = "income"
                dict1["content"] = "您已於" + dateString + "獲得" + String(i.point) + " pt."
                self.info.append(dict1)
            }
        }
        self.reloadData()
    }
    
}
