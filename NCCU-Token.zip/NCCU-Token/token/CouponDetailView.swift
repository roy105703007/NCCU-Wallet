//
//  CouponDetailView.swift
//  token
//
//  Created by 王瀚 on 2019/7/28.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

struct CouponExchangeResult: Codable {
    var msg: String
    var status: Bool
}

class CouponDetailViewController: UIViewController{
    var price: Int!
    var name: String!
    var couponID: String!
    var passwordReceive: String!
    var couponExchangeResult: CouponExchangeResult!
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        transitioningDelegate = self
        self.view.backgroundColor = .invertMain
        self.view.layer.backgroundColor = UIColor.invertMain.cgColor
        /*
        let backBtn = MainButton()
        backBtn.center = CGPoint(x: fullScreenSize.width/2, y: fullScreenSize.height/2)
        backBtn.setTitle("Back", for: .normal)
        backBtn.addTarget(self, action: #selector(self.onDismiss), for: .touchUpInside)
        self.view.addSubview(backBtn)*/
        
        let couponDetailHeader = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 330))
        let couponDetailHeaderContent = UIView(frame: couponDetailHeader.frame)
        couponDetailHeader.addSubview(couponDetailHeaderContent)
        couponDetailHeader.clipsToBounds = false
        couponDetailHeader.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: couponDetailHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        let bg = UIImageView()
        if let bgImg = UIImage(named: "couponDetailDeco"){
            bg.image = bgImg
            let ratio = bgImg.size.width / bgImg.size.height
            let newHeight = fullScreenSize.width / ratio
            bg.frame.size = CGSize(width: fullScreenSize.width, height: newHeight)
        }
        bg.frame.origin = CGPoint(x: 0, y: couponDetailHeader.frame.height - bg.frame.height)
        couponDetailHeaderContent.backgroundColor = .invertMain
        couponDetailHeaderContent.addSubview(bg)
    
        let backButton = UIButton(frame: CGRect(x: 0, y: statusBarHeight, width: 188, height: 44))
        backButton.backgroundColor = .clear
        backButton.setImage(UIImage(named: "backIcon"), for: .normal)
        backButton.setTitle(lang["getCoupon"], for: .normal)
        backButton.setTitleColor(.main, for: .normal)
        backButton.contentMode = .left
        backButton.imageView?.contentMode = .scaleAspectFit
        backButton.contentHorizontalAlignment = .left
        
        backButton.imageEdgeInsets = UIEdgeInsets(top: 12, left: 0, bottom: 12, right: -5)
        backButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: -8, bottom: 0, right: 0)
        
 
        backButton.addTarget(self, action: #selector(self.onDismiss), for: .touchUpInside)
        couponDetailHeaderContent.addSubview(backButton)
        
        let couponImg = UIImageView(frame: CGRect(x: 0, y: backButton.frame.origin.y + backButton.frame.height, width: fullScreenSize.width, height: 140))
        couponImg.contentMode = .scaleAspectFit
        couponDetailHeaderContent.addSubview(couponImg)
        couponImg.downloaded(from: "https://media.ticketxpress.com.tw/Images/361a75f8-64f1-42cd-8a01-29d8071ac540.jpg", contentMode: .scaleAspectFit)
        couponImg.norm()
        
        let couponPrice = UILabel()
        print(self.couponID)
        couponPrice.text =  "\(price!) pt"
        couponPrice.font = .mediBold
        couponPrice.textColor = .lightBlue
        couponPrice.sizeToFit()
        
        let couponTitle = UILabel(frame: CGRect(x: CGFloat(viewLeftLine), y: couponImg.frame.origin.y + couponImg.frame.height + between.height, width: fullViewSize.width - between.width - couponPrice.frame.width, height: 22))
        couponTitle.text = name!
        couponTitle.font = .big
        couponTitle.textColor = .black
        
        couponPrice.frame.origin = CGPoint(x: CGFloat(viewRightLine) - couponPrice.frame.width, y: couponTitle.frame.origin.y + couponTitle.frame.height - couponPrice.frame.height)
        
        couponDetailHeaderContent.addSubview(couponPrice)
        couponDetailHeaderContent.addSubview(couponTitle)
        
        let confirmPurchaseButton = MainButton()
        confirmPurchaseButton.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: fullScreenSize.height - confirmPurchaseButton.frame.height - between.height)
        confirmPurchaseButton.setTitle("\(String(lang["confirmPurchase"]!)) (\(String(lang["confirmPurchaseCost"]!)) \(price!)pt)", for: .normal)
        confirmPurchaseButton.addTarget(
            self,
            action: #selector(getPassword(_:)),
            for: .touchUpInside)
        self.view.addSubview(confirmPurchaseButton)
        
        bg.norm()
        couponDetailHeaderContent.norm()
        couponDetailHeader.norm()
        self.view.addSubview(couponDetailHeader)
        self.view.norm()

        
    }
    @objc func onDismiss(){
        dismiss(animated: true, completion: nil)
    }
    func exchangeCoupon(){
        let params = ["product_id" : self.couponID!, "point" : self.price!] as [String : Any]
        Alamofire.request(serverIP + "/exchange_coupon", method: .post, parameters: params, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            if let exchangeResponse = response.data, let exchangeResult = try?decoder.decode(CouponExchangeResult.self, from: exchangeResponse) {
                if(response.result.isSuccess){
                    self.couponExchangeResult = exchangeResult
                    let alertController = UIAlertController(title: "交易已送出\n", message: "可於交易結果查詢", preferredStyle: UIAlertController.Style.alert)
                    let transactionSend = UIAlertAction(title: "我知道了", style: UIAlertAction.Style.default){(_) in
                        self.updateTotalPoint()
                    }
                    alertController.addAction(transactionSend)
                    self.present(alertController, animated: true, completion: nil)
                }
                else{
                    let alertController = UIAlertController(title: self.couponExchangeResult.msg, message: "", preferredStyle: UIAlertController.Style.alert)
                    alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
        }
    }
    func updateTotalPoint(){
        Alamofire.request(serverIP + "/points", encoding: JSONEncoding.default, headers: header!).responseJSON { (response:DataResponse<Any>) in
            if response.result.isSuccess {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                print(response.result.value)
                if let result = response.data, let pointsResult = try?decoder.decode(PointsResult.self, from: result) {
                    if(pointsResult.status){
                        totalPoint = pointsResult.points
                        self.getCouponInfo()
                    }
                }
            }
        }
    }
    func getCouponInfo(){
        Alamofire.request(serverIP + "/coupon", method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            print(response.result.value)
            if let couponResult = response.data, let couponInfoResult = try?decoder.decode(CouponResult.self, from: couponResult) {
                couponsResults = couponInfoResult
                
                Alamofire.request(serverIP + "/coupon/owned", method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    
                    if let ownedCoupons: NSArray = (response.result.value as! NSDictionary)["coupons"] as! NSArray  {
                        //let myCoupons = ownedCouponsResult["coupons"] as! [String:Any]
                        myCouponsResults = [MyCoupon]()
                        for item in ownedCoupons {
                            let hold = item
                            let _authCode = (hold as! NSDictionary)["authCode"] as! String
                            let _exchangeDate = (hold as! NSDictionary)["exchange_date"] as! String
                            var _expiredDate = (hold as! NSDictionary)["expiryDate"] as! String
                            let dateSeperated =   _expiredDate.components(separatedBy: " ")//seperate a fucking long timestamp from backend.
                            let timeSeperated = dateSeperated[4].components(separatedBy: ":")//separate hours, mins, secs
                            let monthHold = monthAlphaToMonthDigit(mon: dateSeperated[1] )
                            _expiredDate = dateSeperated[3] + monthHold + dateSeperated[2] + timeSeperated[0] + timeSeperated[1] + timeSeperated[2]
                            let _url = (hold as! NSDictionary)["url"] as! String
                            let _productObject = (hold as! NSDictionary)["product"] as! NSDictionary
                            let _product = _productObject["name"] as! String
                            let _image = _productObject["image"] as! String
                            let _id = _productObject["_id"] as! String
                            
                            let _used = (hold as! NSDictionary)["used"] as! Bool
                            myCouponsResults.append(MyCoupon(authCode: _authCode, exchangeDate: _exchangeDate, expiredDate: _expiredDate, image: _image, product: _product, url: _url, used: _used, id : _id))
                        }
                    }
                    else {
                        print("errorFromMyOwnedCoupons")
                    }
                    self.onDismiss()
                }
            }
            else {
                print("errorWhere?")
            }
        }
    }
    @objc func getPassword(_ sender: UIButton){
        if(totalPoint < 0){
            let alertController = UIAlertController(title: "餘額不足\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        else{
            var topController = UIApplication.shared.keyWindow?.rootViewController
            while ((topController?.presentedViewController) != nil) {
                topController = topController?.presentedViewController;
            }
            let tac = KeyInPasswordViewController()
            tac.modalPresentationStyle = UIModalPresentationStyle.custom
            tac.delegate = self
            topController?.present(tac, animated: true, completion: nil)
            return
            
        }        
    }
}
extension CouponDetailViewController : DismissBackDelegate {
    func dismissBack(pwd: String, cancel: Bool){
        passwordReceive = pwd
        print(passwordReceive)
        //暫時註解，測試交易
        exchangeCoupon()
    }
}
extension CouponDetailViewController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return CouponDetailAnimationController(animationDuration: 0.5, animationType: .present)
    }
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return CouponDetailAnimationController(animationDuration: 0.5, animationType: .dismiss)
    }
}
