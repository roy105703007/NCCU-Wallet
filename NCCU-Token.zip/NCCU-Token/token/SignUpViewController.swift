//
//  SignUpViewController.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/10.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import UIKit
import Alamofire
import web3swift
import LocalAuthentication

let web3 = Web3.Utils.self
let userDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
let keystoreManager = KeystoreManager.managerForPath(userDir + "/keystore")

//in the test mode, when you sign up, it will store a new private key instead of the old one. Otherwise, it will alert you that you already have private key on this device.
let testMode = true

class SignUpView: UIViewController {
    
    struct SignUpResult: Codable {
        var msg: String
        var status: Bool
    }
    struct Credentials {
        var username: String
        var password: String
    }
    struct KeychainError: Error {
        var status: OSStatus
        @available(iOS 11.3, *)
        var localizedDescription: String {
            return SecCopyErrorMessageString(status, nil) as String? ?? "Unknown error."
        }
    }
    
    let titleTextArea = UIView()
    
    let titleText = UILabel(frame: CGRect(x: 0, y: between.height*2, width: fullScreenSize.width, height: 20))
    
    let IDText = UILabel(frame: CGRect(x: viewPaddingSize, y: 0, width: Int(fullScreenSize.width), height: 20))
    var IDInput: MainInput? = nil

    let userNameText = UILabel(frame: CGRect(x: viewPaddingSize, y: 0, width: Int(fullScreenSize.width), height: 20))
    var userNameInput: MainInput? = nil

    let emailText = UILabel(frame: CGRect(x: viewPaddingSize, y: 0, width: Int(fullScreenSize.width), height: 20))
    var emailInput: MainInput? = nil
    
    let firstPasswordText = UILabel(frame: CGRect(x: viewPaddingSize, y: 0, width: Int(fullScreenSize.width), height: 20))
    var firstPasswordInput: MainInput? = nil
    
    let passwordHintText = UILabel(frame: CGRect(x: viewPaddingSize, y: 0, width: Int(fullScreenSize.width), height: 10))
    
    let confirmPasswordText = UILabel(frame: CGRect(x: viewPaddingSize, y: 0, width: Int(fullScreenSize.width), height: 20))
    var confirmPasswordInput: MainInput? = nil
    let signupSV = UIScrollView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height))
    
    var confirmBtn = MainButton(inline:2)
    var cancelBtn = MainButton(inline:2)

    override func viewDidLoad() {
        super.viewDidLoad()
        titleText.textAlignment = NSTextAlignment.center
        titleText.text = "註冊"
        titleText.textColor = .main
        titleText.font = .mediBold
        titleText.textAlignment = .center
        titleText.frame = CGRect(x: 0, y: statusBarHeight, width: fullScreenSize.width, height: CGFloat((UIDevice.hasNotch ? 88 : 64) - statusBarHeight - 2))
        titleText.backgroundColor = .clear
        
        titleTextArea.frame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: CGFloat(UIDevice.hasNotch ? 88 : 64))
        titleTextArea.addSubview(titleText)
        titleTextArea.addShadow(radius: 1, opacity: 0.5)
        titleTextArea.backgroundColor = .bgColor
        
        IDText.textAlignment = NSTextAlignment.left
        IDText.text = "帳號(學號)"
        IDText.textColor = .main
        IDText.font = .norm
        IDText.frame.origin = CGPoint(x: viewLeftLine, y: 0)
        
        IDInput = MainInput.init()
        IDInput?.placeholder = "請輸入您的帳號..."
        IDInput!.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: IDText.frame.origin.y + IDText.frame.height + gutter.height)
//        IDInput!.delegate = self
        
        userNameText.textAlignment = NSTextAlignment.left
        userNameText.text = "姓名"
        userNameText.textColor = .main
        userNameText.font = .norm
        userNameText.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: IDInput!.frame.origin.y + IDInput!.frame.height + between.height)
        
        userNameInput = MainInput.init()
        userNameInput?.center = CGPoint(x: fullScreenSize.width/2, y: 300)
        userNameInput?.placeholder = "請輸入您的姓名..."
        userNameInput!.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: userNameText.frame.origin.y + userNameText.frame.height + gutter.height)
        
        emailText.textAlignment = NSTextAlignment.left
        emailText.text = "信箱"
        emailText.textColor = .main
        emailText.font = .norm
        emailText.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: userNameInput!.frame.origin.y + userNameInput!.frame.height + between.height)
        
        emailInput = MainInput.init()
        emailInput?.center = CGPoint(x: fullScreenSize.width/2, y: 400)
        emailInput?.placeholder = "請輸入您的信箱..."
        emailInput!.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: emailText.frame.origin.y + emailText.frame.height + gutter.height)
        
        firstPasswordText.textAlignment = NSTextAlignment.left
        firstPasswordText.text = "密碼"
        firstPasswordText.textColor = .main
        firstPasswordText.font = .norm
        firstPasswordText.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: emailInput!.frame.origin.y + emailInput!.frame.height + between.height)
        
        firstPasswordInput = MainInput.init()
        firstPasswordInput?.center = CGPoint(x: fullScreenSize.width/2, y: 500)
        firstPasswordInput?.placeholder = "請輸入您的密碼..."
        firstPasswordInput?.isSecureTextEntry = true
        firstPasswordInput!.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: firstPasswordText.frame.origin.y + firstPasswordText.frame.height + gutter.height)

        passwordHintText.textAlignment = NSTextAlignment.left
        passwordHintText.text = "密碼長度在6-16字元，只能包含英數字"
        passwordHintText.textColor = .main
        passwordHintText.font = .small
        passwordHintText.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: firstPasswordInput!.frame.origin.y + firstPasswordInput!.frame.height + 5)
        
        confirmPasswordText.textAlignment = NSTextAlignment.left
        confirmPasswordText.text = "再次輸入密碼"
        confirmPasswordText.textColor = .main
        confirmPasswordText.font = .norm
        confirmPasswordText.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: passwordHintText.frame.origin.y + passwordHintText.frame.height + between.height)
        
        confirmPasswordInput = MainInput.init()
        confirmPasswordInput?.center = CGPoint(x: fullScreenSize.width/2, y: 600)
        confirmPasswordInput?.placeholder = "請再次輸入您的密碼..."
        confirmPasswordInput?.isSecureTextEntry = true
        confirmPasswordInput!.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: confirmPasswordText.frame.origin.y + confirmPasswordText.frame.height + gutter.height)

        confirmBtn.setTitle("註冊", for: .normal)
        confirmBtn.setTitleColor(.white, for: .normal)
        confirmBtn.tag = 0
        confirmBtn.titleLabel?.font = .norm
        confirmBtn.addTarget(
            self,
            action: #selector(signUp(_:)),
            for: .touchUpInside)
        
        cancelBtn.setTitle("取消", for: .normal)
        cancelBtn.setTitleColor(.white, for: .normal)
        cancelBtn.backgroundColor = .lightBlue
        cancelBtn.tag = 1
        cancelBtn.titleLabel?.font = .norm
        cancelBtn.addTarget(
            self,
            action: #selector(cancel(_:)),
            for: .touchUpInside)
        
        let btnArea = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: confirmBtn.frame.height + gutter.height * 2 + (UIDevice.hasNotch ? between.height : 0)))
        btnArea.frame.origin = CGPoint(x: 0, y: fullScreenSize.height - btnArea.frame.height)
        confirmBtn.frame.origin = CGPoint(x: fullScreenSize.width/2 + CGFloat(viewPaddingSize/2), y: gutter.height)
        cancelBtn.frame.origin = CGPoint(x: CGFloat(viewPaddingSize), y: gutter.height)
        btnArea.addSubview(confirmBtn)
        btnArea.addSubview(cancelBtn)
        btnArea.backgroundColor = .bgColor
        btnArea.addShadow(radius: 1, opacity: 0.5)
        
        signupSV.addSubview(IDText)
        signupSV.addSubview(IDInput!)
        signupSV.addSubview(userNameText)
        signupSV.addSubview(userNameInput!)
        signupSV.addSubview(emailText)
        signupSV.addSubview(emailInput!)
        signupSV.addSubview(firstPasswordText)
        signupSV.addSubview(firstPasswordInput!)
        signupSV.addSubview(passwordHintText)
        signupSV.addSubview(confirmPasswordText)
        signupSV.addSubview(confirmPasswordInput!)

        signupSV.contentSize = CGSize(width: fullScreenSize.width, height: max(confirmPasswordInput!.frame.origin.y + confirmPasswordInput!.frame.height, fullScreenSize.height))
        signupSV.keyboardDismissMode = .onDrag
        self.view.addSubview(signupSV)
        self.view.addSubview(titleTextArea)
        self.view.addSubview(btnArea)
        titleTextArea.norm()
        btnArea.norm()
        signupSV.contentInset = UIEdgeInsets(top: titleTextArea.frame.height + between.height, left: 0, bottom: btnArea.frame.height, right: 0)
        signupSV.setContentOffset(CGPoint(x: 0, y: -1 * (titleTextArea.frame.height + between.height)), animated: false)
        self.view.backgroundColor = UIColor.white
        
        var tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(DismissKeyboard))
        view.addGestureRecognizer(tap)
        //test()
    }
    
    func deleteCredentials(server: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                    kSecAttrServer as String: server]
        
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess else { throw KeychainError(status: status) }
    }
    
    @objc func DismissKeyboard(){
        self.view.endEditing(true)
    }
    
    @objc func signUp(_ sender: Any) {
        //刪掉原先的keychain
        do {
            try deleteCredentials(server: serverIP)
            
        } catch {
            if let error = error as? KeychainError {
                
            }
        }
        //註冊欄位檢查
        if(IDInput!.text == ""){
            let alertController = UIAlertController(title: "學號不得為空\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
            
        else if(userNameInput!.text == ""){
            let alertController = UIAlertController(title: "姓名不得為空\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
            
        else if(emailInput!.text == ""){
            let alertController = UIAlertController(title: "E-mail不得為空\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
            
        else if((emailInput!.text?.contains("@nccu.edu.tw"))! == false){
            let alertController = UIAlertController(title: "請使用政大E-mail\n", message: "@nccu.edu.tw", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
 
        else if(firstPasswordInput!.text!.count < 6 || firstPasswordInput!.text!.count > 16){
            let alertController = UIAlertController(title: "密碼長度有誤\n", message: "密碼長度在6-16字元，只能包含英數字", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
        else if(firstPasswordInput!.text! != confirmPasswordInput!.text!){
            let alertController = UIAlertController(title: "兩次密碼輸入不同\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
            
        //檢查通過
        else{
            let passwordHash: String = firstPasswordInput!.text!.md5()
            let password = firstPasswordInput!.text! // We recommend here and everywhere to use the password set by the user.
            let name = userNameInput!.text!
            let address = generateAccount(password: passwordHash)
            
            if((address == "已綁定帳戶" || address == "裝置空間不足") && testMode == false){
                let alertController = UIAlertController(title: address + "\n", message: "", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
                
            }
            let apiString = "http://wm.nccu.edu.tw:3001/innerapi/register?" +
                "name=" + userNameInput!.text! + "&" + "email=" + emailInput!.text! + "&" +
                "password=" + passwordHash + "&" + "student_id=" + IDInput!.text! + "&" +
                "address=" + address
            print(apiString)
            /*
            原註冊api
            let params = ["ID": IDInput!.text!, "name": userNameInput!.text!, "email": emailInput!.text!, "password": firstPasswordInput!.text!, "address": address]
 
            Alamofire.request(serverIP + "/signUP", method: .post, parameters: params, encoding: JSONEncoding.default).responseJSON { (response) in
             */
            
            //send request
            Alamofire.request(apiString, method: .get, encoding: JSONEncoding.default).responseJSON { (response) in
    
                if response.result.isSuccess {
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    print(response.result.value)
                    if let logInResult = response.data, let signUpResult = try?decoder.decode(SignUpResult.self, from: logInResult) {
                        if(signUpResult.status){
                            self.performSegue(withIdentifier: "signUpSuccess", sender: sender)
                            //add credential to keychain
                            let credentials = Credentials(username: self.emailInput!.text!, password: password)
                            do {
                                try self.addCredentials(credentials, server: serverIP)
                            } catch {
                                if error is KeychainError {
                                    let keychainErrorAlert = UIAlertController(title: "keychain", message: "error.localizedDescription", preferredStyle: .alert)
                                    let okAction = UIAlertAction(title: "確認", style: .default, handler: nil)
                                    keychainErrorAlert.addAction(okAction)
                                    self.present(keychainErrorAlert, animated: true, completion: nil)
                                }
                            }
                            
                        }
                            
                        else{
                            let alertController = UIAlertController(title: signUpResult.msg + "\n", message: "", preferredStyle: UIAlertController.Style.alert)
                            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alertController, animated: true, completion: nil)
                        }
                    }
                    else{
                        let alertController = UIAlertController(title: "網路連線錯誤\n", message: "", preferredStyle: UIAlertController.Style.alert)
                        alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alertController, animated: true, completion: nil)
                        
                    }
                }
    
                else{
                    print("error!")
                }
            }
            
        }
    }
    
    @objc func cancel(_ sender: UIButton){
        self.performSegue(withIdentifier: "cancelSignUp", sender: sender)
    }
    
    func generateAccount(password: String)-> String {
        let keystore = try! EthereumKeystoreV3.init(password: password)!
        let address = keystore.addresses!.first!.address
        //print(keystore.keystoreParams)
        do{
            
            
            if (keystoreManager?.addresses?.count == 0 || testMode == true) {

                let keydata = try JSONEncoder().encode(keystore.keystoreParams)
                
                if (keystoreManager?.addresses?.count == 0) {
                    FileManager.default.createFile(atPath: userDir + "/keystore"+"/key.json", contents: keydata, attributes: nil)
                }
                print(userDir + "/keystore"+"/key.json")
                
                return (keystoreManager?.addresses!.first!.address)!
            }
            else{
                return "已綁定帳戶"
            }
        }
        catch{
            print(error.localizedDescription)
        }
        return "裝置空間不足"
    }
    // add keychain data which can be accessed by touch id
    func addCredentials(_ credentials: Credentials, server: String) throws {
        // Use the username as the account, and get the password as data.
        let account = credentials.username
        let password = credentials.password.data(using: String.Encoding.utf8)!
        
        // Create an access control instance that dictates how the item can be read later.
        let access = SecAccessControlCreateWithFlags(nil, // Use the default allocator.
            kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
            .userPresence,
            nil) // Ignore any error.
        
        // Allow a device unlock in the last 10 seconds to be used to get at keychain items.
        let context = LAContext()
        context.touchIDAuthenticationAllowableReuseDuration = 10
        
        // Build the query for use in the add operation.
        let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                    kSecAttrAccount as String: account,
                                    kSecAttrServer as String: server,
                                    kSecAttrAccessControl as String: access as Any,
                                    kSecUseAuthenticationContext as String: context,
                                    kSecValueData as String: password]
        
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else { throw KeychainError(status: status) }
    }
    func test(){
        let str = "02282040"
        let result1 = generateAccount(password : str.md5())
        print(result1)
        let addr : EthereumAddress = (keystoreManager!.addresses?.first!)!
        let pkData = try! keystoreManager!.UNSAFE_getPrivateKeyData(password: str.md5(), account: addr)
        print(pkData)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let button = sender as? UIButton{
            if button.tag == 0 {
                let controller = segue.destination as? SignUpSuccessView
            }
            else if button.tag == 1 {
                let controller = segue.destination as? LogInView
            }
        }
    }
    
}
