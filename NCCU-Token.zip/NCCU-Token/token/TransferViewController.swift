//
//  File.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/20.
//  Copyright © 2019 徐胤桓. All rights reserved.
//
import UIKit
import Alamofire

protocol UpdateTotalPointDelegate {
    func dismissAndUpdateTotalPoint(update: Int)
}

protocol GetAccountId {
    func getAccountIdToTransfer(sentData: String)
}

class TransferView: UIViewController, UITextFieldDelegate{

    var balanceLabel: UILabel?
    var balanceNum: UILabel?
    let inputAccount = MainInput()
    var accountId = ""
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
        

        balanceNum!.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .main),("pt", UIFont.medi, .lightBlue)])

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.invertMain
        
        let tapGestureBackground = UITapGestureRecognizer(target: self, action: #selector(backgroundTapped))
        self.view.addGestureRecognizer(tapGestureBackground)
        
        let transferHeader = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: (UIDevice.hasNotch ? 113 : 101)))
        let transferHeaderContent = UIView(frame: transferHeader.frame)
        transferHeaderContent.backgroundColor = .invertMain
        transferHeader.addSubview(transferHeaderContent)
        transferHeader.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: transferHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        
        balanceLabel = UILabel(frame: CGRect(x: viewLeftLine + Int(gutter.width), y: Int(statusBarHeight) + Int(between.height) - (UIDevice.hasNotch ? 15 : 10), width: 100, height: 40))
        balanceLabel!.font = .norm
        balanceLabel!.textColor = .gray
        balanceLabel!.text = lang["mybalance"]
        transferHeaderContent.addSubview(balanceLabel!)
        
        balanceNum = UILabel(frame: CGRect(x: 0, y: 0, width: fullViewSize.width - gutter.width * 2 - balanceLabel!.frame.width, height: 40))
        balanceNum!.multiStyle(content: [(String(totalPoint), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .main),("pt", UIFont.medi, .lightBlue)])
        balanceNum!.textAlignment = .right
        balanceNum!.frame.origin = CGPoint(x: viewRightLine - gutter.width - balanceNum!.frame.width, y: statusBarHeight + between.height - (UIDevice.hasNotch ? 15 : 10))
        transferHeaderContent.addSubview(balanceNum!)
        
        let inputAccountHint = UILabel(frame: CGRect(x: 0, y: transferHeader.frame.origin.y + transferHeader.frame.height + between.height * 2, width: fullScreenSize.width, height: 22))
        inputAccountHint.text = lang["transferAccountHint"]
        inputAccountHint.textAlignment = .center
        inputAccountHint.font = .big
        inputAccountHint.textColor = .main
        self.view.addSubview(inputAccountHint)
        
        
        inputAccount.text = accountId
        inputAccount.placeholder = lang["transferAccountPlaceholder"]
        inputAccount.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: inputAccountHint.frame.origin.y + inputAccountHint.frame.height + between.height)
        inputAccount.returnKeyType = .next
        inputAccount.delegate = self

        self.view.addSubview(inputAccount)
        
        let  path = UIBezierPath()
        let  p0 = CGPoint(x: 0, y: inputAccount.frame.origin.y + inputAccount.frame.height + between.height * 2)
        path.move(to: p0)
        let  p1 = CGPoint(x: fullScreenSize.width, y: inputAccount.frame.origin.y + inputAccount.frame.height + between.height * 2)
        path.addLine(to: p1)
        let dashLine = CAShapeLayer()
        dashLine.strokeColor = UIColor.main.cgColor
        dashLine.lineWidth = 1
        dashLine.lineDashPattern = [4, 4]
        dashLine.fillColor = nil
        dashLine.path = path.cgPath
        dashLine.rasterizationScale = UIScreen.main.scale;
        dashLine.shouldRasterize = true;
        self.view.layer.addSublayer(dashLine)
        
        let orLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 70, height: 22))
        orLabel.text = lang["or"]
        orLabel.textAlignment = .center
        orLabel.font = .bigBold
        orLabel.textColor = .main
        orLabel.backgroundColor = .invertMain
        orLabel.center = CGPoint(x: fullScreenSize.width / 2, y: inputAccount.frame.origin.y + inputAccount.frame.height + between.height * 2 - 0.5)
        self.view.addSubview(orLabel)
        
        let scanQrcodeButton = UIView()
        scanQrcodeButton.frame = CGRect(x: 0, y: 0, width: 200, height: 115)
        scanQrcodeButton.center = CGPoint(x: fullScreenSize.width / 2, y: orLabel.frame.origin.y + orLabel.frame.height + between.height * 2 + scanQrcodeButton.frame.height / 2)
        let qrcodeIcon = UIImageView(image: UIImage(named: "qrcodeBtn")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate))
        qrcodeIcon.tintColor = .lightBlue
        qrcodeIcon.frame = CGRect(x: (scanQrcodeButton.frame.width - 70) / 2, y: 0, width: 70, height: 70)
        scanQrcodeButton.addSubview(qrcodeIcon)
        let qrcodeLabel = UILabel(frame: CGRect(x: 0, y: scanQrcodeButton.frame.height - 15, width: scanQrcodeButton.frame.width, height: 17))
        qrcodeLabel.textAlignment = .center
        qrcodeLabel.text = lang["transferUsingQrcode"]
        qrcodeLabel.textColor = .main
        qrcodeLabel.font = .medi
        scanQrcodeButton.addSubview(qrcodeLabel)
        self.view.addSubview(scanQrcodeButton)
        
        scanQrcodeButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(openQRCodeScanner)))
        
        transferHeaderContent.norm()
        transferHeader.norm()
        self.view.addSubview(transferHeader)
        self.view.norm()

    }
    
    @objc func openQRCodeScanner(_ sender: UITapGestureRecognizer){
        var topController = UIApplication.shared.keyWindow?.rootViewController
        while ((topController?.presentedViewController) != nil) {
            topController = topController?.presentedViewController;
        }
        let qrcview = QRScannerController()
        qrcview.delegate = self
        qrcview.modalPresentationStyle = UIModalPresentationStyle.custom
        topController?.present(qrcview, animated: true, completion: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(!textField.text!.contains(/*"@nccu.edu.tw"*/"1")){
            let alertController = UIAlertController(title: "請確認格式是否正確\n", message: "需包含'@nccu.edu.tw'!", preferredStyle: UIAlertController.Style.alert)
            let checkEmail = UIAlertAction(title: "我知道了", style: UIAlertAction.Style.default){(_) in
            }
            alertController.addAction(checkEmail)
            self.present(alertController, animated: true, completion: nil)
            return false

        }
        else{
            textField.resignFirstResponder()
            var topController = UIApplication.shared.keyWindow?.rootViewController
            while ((topController?.presentedViewController) != nil) {
                topController = topController?.presentedViewController;
            }
            let tac = TransferAmountController()
            tac.modalPresentationStyle = UIModalPresentationStyle.custom
            tac.account = textField.text!
            tac.accountDisplay.text = textField.text!
            tac.delegate = self
            topController?.present(tac, animated: true, completion: nil)
            return true
            
        }
    }
    
    @objc func backgroundTapped(_ sender: UITapGestureRecognizer)
    {
        self.view.backgroundColor = UIColor.white

    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
 
    
    /*
    func getPrivateKey(){
        //this should be unlock by faceID, password etc.
        let password = UserDefaults.standard.object(forKey: "password") as! String
        //
        print(password)
        if let privatekey = try? keystoreManager?.UNSAFE_getPrivateKeyData(password: password, account: ((keystoreManager?.addresses!.first)!)){
            self.privateKey = privatekey
            print("pkey",privatekey.toHexString())
        }
    }*/
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }

    
}
extension TransferView : UpdateTotalPointDelegate {
    func dismissAndUpdateTotalPoint(update: Int){
        balanceNum!.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .main),("pt", UIFont.medi, .lightBlue)])
        self.dismiss(animated: true, completion: nil)

    }
}

extension TransferView : GetAccountId {
    func getAccountIdToTransfer(sentData: String) {
        accountId = sentData
        inputAccount.text = accountId
        inputAccount.textColor = UIColor.black
        print(accountId)
    }
}
