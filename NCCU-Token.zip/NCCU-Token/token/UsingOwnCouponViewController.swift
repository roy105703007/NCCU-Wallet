//
//  UsingOwnCouponViewController.swift
//  token
//
//  Created by 王瀚 on 2019/7/28.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

var useOverlayView = UIVisualEffectView()

public class UsingOwnCouponViewController{
    var useOverlayView = UIVisualEffectView()
    var modalLayer = UIView()
    var confirmFilter = MainButton()
    var couponUrl = "https://www.google.com"
    var couponAuthCode = "XXXX"
    var id = ""
    class var shared: UsingOwnCouponViewController {
        struct Static {
            static let instance: UsingOwnCouponViewController = UsingOwnCouponViewController()
        }
        return Static.instance
    }
    
    public func showOverlay(authCode: String, name: String, url: String, id: String) {
        if  let appDelegate = UIApplication.shared.delegate as? AppDelegate, let window = appDelegate.window {
            couponUrl = url
            couponAuthCode = authCode
            useOverlayView.frame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height)
            useOverlayView.backgroundColor = .clear
            useOverlayView.clipsToBounds = true
            self.id = id
            window.addSubview(useOverlayView)
            
            let closeTriger = UIButton(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height))
            closeTriger.addTarget(self, action:  #selector(self.hideoverlayView), for: .touchUpInside)
            useOverlayView.contentView.addSubview(closeTriger)
            
            let modalContent = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 410))
            modalLayer.frame = CGRect(x: 0, y: fullScreenSize.height, width: fullScreenSize.width, height: 410)
            modalLayer.roundCorners(corners: [.topLeft,.topRight], radius: 10, content: modalContent, shadowRadius: 2, shadowOpacity: 0.15)
            modalLayer.norm()
            modalContent.backgroundColor = .invertMain
            modalLayer.addSubview(modalContent)
            useOverlayView.contentView.addSubview(modalLayer)
            
            let couponName = UILabel(frame: CGRect(x: between.width, y: between.height, width: fullScreenSize.width - 2*between.width, height: 24))
            couponName.text = name
            couponName.textColor = .main
            couponName.font = .bigBold
            couponName.textAlignment = .center
            modalContent.addSubview(couponName)
            
            let authCodeArea = UIView(frame: CGRect(x: 2*between.width, y: between.height + couponName.frame.origin.y + couponName.frame.height, width: fullScreenSize.width - 4*between.width, height: 100))
            authCodeArea.addDashBorder(color: UIColor.main, width: 2, dash: [4,4])
            authCodeArea.backgroundColor = .clear
            
            let authCodeTitle = UILabel(frame: CGRect(x: 0, y: 15, width: fullScreenSize.width - 4*between.width, height: 15))
            authCodeTitle.text = "驗證碼"
            authCodeTitle.textColor = .main
            authCodeTitle.font = .norm
            authCodeTitle.textAlignment = .center
            authCodeArea.addSubview(authCodeTitle)
            
            let authCodeContent = UILabel(frame: CGRect(x: 0, y: 45, width: fullScreenSize.width - 4*between.width, height: 40))
            authCodeContent.text = authCode.inserting(separator: " ", every: 1)
            authCodeContent.textColor = .darkRed
            authCodeContent.font = UIFont.systemFont(ofSize: fontSizeHuge, weight: UIFont.Weight.light)
            authCodeContent.textAlignment = .center
            authCodeArea.addSubview(authCodeContent)
            
            modalContent.addSubview(authCodeArea)
            
            let getCouponHint = UILabel(frame: CGRect(x: (fullScreenSize.width - 250)/2, y: authCodeArea.frame.height + authCodeArea.frame.origin.y + between.height, width: 250, height: 0))
            getCouponHint.text = "請點擊按鈕前往網站，並輸入驗證碼使用電子禮券。"
            getCouponHint.numberOfLines = 2
            getCouponHint.font = .norm
            getCouponHint.textColor = .main
            getCouponHint.textAlignment = .center
            getCouponHint.sizeToFit()
            modalContent.addSubview(getCouponHint)
            
            let confirmUseCoupon = MainButton(inline: 2)
            confirmUseCoupon.frame.origin = CGPoint(x: fullScreenSize.width/2 + CGFloat(viewPaddingSize/2), y: 410 - confirmUseCoupon.frame.height - between.height)
            confirmUseCoupon.setTitle("前往網站使用",for: UIControl.State.normal)
            confirmUseCoupon.addTarget(self, action:  #selector(self.confirm), for: .touchUpInside)
            modalContent.addSubview(confirmUseCoupon)
            
            let reportUsedCoupon = MainButton(inline: 2)
            reportUsedCoupon.backgroundColor = .lightBlue
            reportUsedCoupon.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: 410 - confirmUseCoupon.frame.height - between.height)
            reportUsedCoupon.setTitle("回報已使用",for: UIControl.State.normal)
            reportUsedCoupon.addTarget(self, action:  #selector(self.reportUsed), for: .touchUpInside)
            modalContent.addSubview(reportUsedCoupon)

            
            UIView.animate(withDuration: 0.5) {
                self.useOverlayView.effect = UIBlurEffect(style: UIBlurEffect.Style.light)
            }
            UIView.animate(withDuration: 0.3, delay: 0.3, options: .curveEaseInOut, animations: {
                self.modalLayer.frame.origin.y = fullScreenSize.height - 410
            })
        }
    }
    
    @objc public func hideoverlayView() {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
            self.modalLayer.frame.origin.y = fullScreenSize.height
        })
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseInOut, animations: {
            self.useOverlayView.effect = nil
        },completion: { (finished: Bool) in
            self.useOverlayView.removeFromSuperview()
        })
    }
    @objc public func confirm() {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
            self.modalLayer.frame.origin.y = fullScreenSize.height
        })
        UIView.animate(withDuration: 0.5, delay: 0.1, options: .curveEaseInOut, animations: {
            self.useOverlayView.effect = nil
        },completion: { (finished: Bool) in
            self.useOverlayView.removeFromSuperview()
            guard let url = URL(string: self.couponUrl) else {
                return //be safe
            }
            UIPasteboard.general.string = self.couponAuthCode
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        })
    }
    @objc public func reportUsed() {
        struct ReportUsedResult: Codable {
            var msg: String
            var status: Bool
        }
        let params = ["coupon_id" : id]
        print(id)
        Alamofire.request(serverIP + "/use_coupon", method: .post, parameters: params, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            print(response.result.value)
            if let result = response.data, let reportUsedResult = try?decoder.decode(ReportUsedResult.self, from: result) {
                var topController = UIApplication.shared.keyWindow?.rootViewController
                while ((topController?.presentedViewController) != nil) {
                    topController = topController?.presentedViewController;
                }
                let alertController = UIAlertController(title: reportUsedResult.msg, message: "", preferredStyle: UIAlertController.Style.alert)
                let usedSend = UIAlertAction(title: "我知道了", style: UIAlertAction.Style.default){(_) in
                    self.getCouponInfo()
                }
                alertController.addAction(usedSend)
                topController?.present(alertController, animated: true, completion: nil)
            }
        }
    }
    func getCouponInfo(){
        Alamofire.request(serverIP + "/coupon/owned", method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            
            if let ownedCoupons: NSArray = (response.result.value as! NSDictionary)["coupons"] as! NSArray  {
                print(ownedCoupons)
                //let myCoupons = ownedCouponsResult["coupons"] as! [String:Any]
                myCouponsResults = [MyCoupon]()
                for item in ownedCoupons {
                    let hold = item
                    let _authCode = (hold as! NSDictionary)["authCode"] as! String
                    let _exchangeDate = (hold as! NSDictionary)["exchange_date"] as! String
                    var _expiredDate = (hold as! NSDictionary)["expiryDate"] as! String
                    let dateSeperated =   _expiredDate.components(separatedBy: " ")//seperate a fucking long timestamp from backend.
                    let timeSeperated = dateSeperated[4].components(separatedBy: ":")//separate hours, mins, secs
                    let monthHold = monthAlphaToMonthDigit(mon: dateSeperated[1] )
                    _expiredDate = dateSeperated[3] + monthHold + dateSeperated[2] + timeSeperated[0] + timeSeperated[1] + timeSeperated[2]
                    let _url = (hold as! NSDictionary)["url"] as! String
                    let _productObject = (hold as! NSDictionary)["product"] as! NSDictionary
                    let _product = _productObject["name"] as! String
                    let _image = _productObject["image"] as! String
                    let _id = _productObject["_id"] as! String
                    
                    let _used = (hold as! NSDictionary)["used"] as! Bool
                    myCouponsResults.append(MyCoupon(authCode: _authCode, exchangeDate: _exchangeDate, expiredDate: _expiredDate, image: _image, product: _product, url: _url, used: _used, id : _id))
                }
            }
            else {
                print("errorFromMyOwnedCoupons")
            }
        }

    }
}

