//
//  KeyInPasswordViewController.swift
//  token
//
//  Created by Roy on 2019/8/5.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import UIKit
import LocalAuthentication

class KeyInPasswordViewController: UIViewController {
    var receivePrivateKey: String = ""

    var delegate: DismissBackDelegate?
    
    struct Credentials {
        var username: String
        var password: String
    }
    struct KeychainError: Error {
        var status: OSStatus
        @available(iOS 11.3, *)
        var localizedDescription: String {
            return SecCopyErrorMessageString(status, nil) as String? ?? "Unknown error."
        }
    }
    let keyInPassword = UITextField(frame: CGRect(x: 0, y: fullScreenSize.height/2 - 30, width: fullScreenSize.width, height: 30))
    let keyPasswordLabel = UILabel(frame: CGRect(x: 0, y: 100, width: fullScreenSize.width, height: 34))
    let comfirmButton = UIButton(frame: CGRect(x: 0, y: fullScreenSize.height/2, width: fullScreenSize.width, height: 30))
    let cancelButton = UIButton(frame: CGRect(x: 0, y: fullScreenSize.height/2 + 120, width: fullScreenSize.width, height: 30))
    let inputPassword = MainInput()
    let nextBtn = MainButton(inline: 2)
    let cancelBtn = MainButton(inline: 2)
    
    override func viewDidAppear(_ animated: Bool) {
        accessKeyChain()
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        inputPassword.isSecureTextEntry = true
        inputPassword.placeholder = lang["keyPasswordHolder"]
        inputPassword.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: 200)
        self.view.addSubview(inputPassword)
        keyPasswordLabel.text = lang["pleaseKeyPassword"]
        keyPasswordLabel.textAlignment = .center
        keyPasswordLabel.textColor = UIColor.main
        keyPasswordLabel.font = UIFont.bigBold
        self.view.addSubview(keyPasswordLabel)
        nextBtn.setTitle(lang["next"], for: UIControl.State.normal)
        nextBtn.frame.origin = CGPoint(x: fullScreenSize.width/2 + gutter.width/2, y: fullScreenSize.height - nextBtn.frame.height - between.height)
        nextBtn.addTarget(
            self,
            action: #selector(nextVC),
            for: .touchUpInside)
        self.view.addSubview(nextBtn)
        cancelBtn.setTitle(lang["cancel"], for: UIControl.State.normal)
        cancelBtn.frame.origin = CGPoint(x: CGFloat(viewPaddingSize), y: fullScreenSize.height - cancelBtn.frame.height - between.height)
        cancelBtn.addTarget(
            self,
            action: #selector(cancel),
            for: .touchUpInside)
        self.view.addSubview(cancelBtn)
        // Do any additional setup after loading the view.
    }
    @objc func cancel(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }
    @objc func nextVC(_ sender: UIButton){
        receivePrivateKey = inputPassword.text!
        self.delegate?.dismissBack(pwd: receivePrivateKey, cancel: true)
        dismiss(animated: true, completion: nil)
    }
    
    func accessKeyChain(){
        do {
            let credentials = try self.readCredentials(server: serverIP)
            inputPassword.text = credentials.password
        } catch {
            if error is KeychainError {
                let keychainErrorAlert = UIAlertController(title: "keychain", message: "error.localizedDescription", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "確認", style: .default, handler: nil)
                keychainErrorAlert.addAction(okAction)
                self.present(keychainErrorAlert, animated: true, completion: nil)
            }
        }
    }
    // use touch ID to access keychain
    func readCredentials(server: String) throws -> Credentials {
        let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                    kSecAttrServer as String: server,
                                    kSecMatchLimit as String: kSecMatchLimitOne,
                                    kSecReturnAttributes as String: true,
                                    kSecUseOperationPrompt as String: "Access your password on the keychain",
                                    kSecReturnData as String: true]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess else { throw KeychainError(status: status) }
        
        guard let existingItem = item as? [String: Any],
            let passwordData = existingItem[kSecValueData as String] as? Data,
            let password = String(data: passwordData, encoding: String.Encoding.utf8),
            let account = existingItem[kSecAttrAccount as String] as? String
            else {
                throw KeychainError(status: errSecInternalError)
        }
        
        return Credentials(username: account, password: password)
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let button = sender as? UIButton
        if(segue.identifier == "transferGetPassword"){
            let controller = segue.destination as? TransferAmountController
            controller?.cancelReceive = true
            controller?.passwordReceive = receivePrivateKey
        }// Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
