//
//  TabBarController.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/20.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import UIKit

@objc protocol LogInReturnDataDelegate {
    func logInReturnData(contact: String)
    //func clearData()
}
class TabBar: UITabBarController {
    override func viewWillLayoutSubviews(){
        var tabFrame:CGRect = self.tabBar.frame
        tabFrame.size.height += 5
        tabFrame.origin.y = self.view.frame.size.height - tabFrame.size.height
        self.tabBar.frame = tabFrame
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 25.0), NSAttributedString.Key.foregroundColor : UIColor.black], for: .normal)
        
        self.tabBar.layer.borderWidth = 0
        self.tabBar.layer.borderColor = UIColor.white.cgColor
        
        // add shadow
        self.tabBar.layer.shadowOffset = CGSize(width: 0,height: 0)
        self.tabBar.layer.shadowOpacity = 0.15
        self.tabBar.layer.shadowRadius = 8
        self.tabBar.layer.shadowColor = UIColor.black.cgColor
        self.tabBar.layer.shadowPath = UIBezierPath(rect: self.tabBar.bounds).cgPath
        self.tabBar.layer.shouldRasterize = true
        self.tabBar.layer.rasterizationScale = 1
        
        // define item tint color
        self.tabBar.tintColor = UIColor.main
        
        // define bgColor & img
        self.tabBar.backgroundColor = UIColor.white
        UITabBar.appearance().shadowImage = UIImage()
        UITabBar.appearance().backgroundImage = UIImage()
        UITabBar.appearance().backgroundColor = UIColor.white
        
        // add radius
        self.tabBar.layer.cornerRadius = 15
        
        let homeView = HomeView()
        homeView.tabBarItem = UITabBarItem(
            title: lang["tabLabelOverview"],
            image: UIImage(named: "overview"),
            selectedImage: UIImage(named: "overviewSelected")
        )
        homeView.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 10)], for: .normal)
        
        let couponView = CouponView()
        couponView.tabBarItem = UITabBarItem(
            title: lang["tabLabelCoupon"],
            image: UIImage(named: "coupon"),
            selectedImage: UIImage(named: "couponSelected")
        )
        
        couponView.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 10)], for: .normal)
        
        let transferView = TransferView()
        transferView.tabBarItem = UITabBarItem(
            title: lang["tabLabelTransfer"],
            image: UIImage(named: "transfer"),
            selectedImage: UIImage(named: "transferSelected")
        )
        
        transferView.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 10)], for: .normal)
        
        let transferLogView = TransferLogsView()
        transferLogView.tabBarItem = UITabBarItem(
            title: lang["tabLabelLogs"],
            image: UIImage(named: "logs"),
            selectedImage: UIImage(named: "logsSelected")
        )
        
        transferLogView.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 10)], for: .normal)
        
        let settingView = SettingView()
        settingView.tabBarItem = UITabBarItem(
            title: lang["tabLabelSetting"],
            image: UIImage(named: "settings"),
            selectedImage: UIImage(named: "settingsSelected")
        )
        
        settingView.tabBarItem.setTitleTextAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 10)], for: .normal)
        
        if(!UIDevice.hasNotch){
            homeView.tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -6)
            couponView.tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -6)
            transferView.tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -6)
            transferLogView.tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -6)
            settingView.tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -6)
        }
        
        self.viewControllers = [homeView, couponView, transferView, transferLogView, settingView]
        // 設定起始頁面
        self.selectedIndex = 0
        

        
        /*  設定個選單的通知數量
        for one in self.tabBar.items! {
            one.badgeValue = "100"
        }
        */
        
    }
    
}
