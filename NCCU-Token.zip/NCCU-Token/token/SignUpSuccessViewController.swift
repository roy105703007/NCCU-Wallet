import UIKit

class SignUpSuccessView: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
        
        self.view.backgroundColor = UIColor.white
        
    }
    
}
