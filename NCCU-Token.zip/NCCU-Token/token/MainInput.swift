//
//  MainInput.swift
//  token
//
//  Created by 王瀚 on 2019/7/21.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit

class MainInput: UITextField, CAAnimationDelegate{
    required init() {
        let frame = CGRect(x: 0, y: 0, width: fullViewSize.width, height: 36)
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setup(){
        backgroundColor = .inputBG
        layer.cornerRadius = CGFloat(cornerRadius)
    }
    let padding = inputPadding
    
    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
    
    override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
    
    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
}
