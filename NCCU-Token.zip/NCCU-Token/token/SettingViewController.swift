//
//  File.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/20.
//  Copyright © 2019 徐胤桓. All rights reserved.
//
import UIKit

class SettingView: UIViewController{
    
    var balanceLabel:UILabel? = nil
    var balanceNum:UILabel? = nil
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
        balanceNum!.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .darkRed),("pt", UIFont.medi, .lightBlue)])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        let transferLogHeader = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: (UIDevice.hasNotch ? 173 : 161)))
        let transferLogHeaderContent = UIView(frame: transferLogHeader.frame)
        transferLogHeaderContent.backgroundColor = .invertMain
        transferLogHeader.addSubview(transferLogHeaderContent)
        transferLogHeader.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: transferLogHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        
        balanceLabel = UILabel(frame: CGRect(x: viewLeftLine + Int(gutter.width), y: Int(statusBarHeight) + Int(between.height) - (UIDevice.hasNotch ? 15 : 10), width: 100, height: 40))
        balanceLabel!.font = .norm
        balanceLabel!.textColor = .gray
        balanceLabel!.text = lang["mybalance"]
        transferLogHeaderContent.addSubview(balanceLabel!)
        
        balanceNum = UILabel(frame: CGRect(x: 0, y: 0, width: fullViewSize.width - gutter.width * 2 - balanceLabel!.frame.width, height: 40))
        balanceNum!.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .main),("pt", UIFont.medi, .lightBlue)])
        balanceNum!.textAlignment = .right
        balanceNum!.frame.origin = CGPoint(x: viewRightLine - gutter.width - balanceNum!.frame.width, y: statusBarHeight + between.height - (UIDevice.hasNotch ? 15 : 10))
        transferLogHeaderContent.addSubview(balanceNum!)
        self.view.addSubview(transferLogHeader)
    }
    
}
