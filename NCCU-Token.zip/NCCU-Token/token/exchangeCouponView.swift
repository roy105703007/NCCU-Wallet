//
//  exchangeCouponView.swift
//  token
//
//  Created by 王瀚 on 2019/7/25.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class ExchangeCouponView: UIView{
    var exchangeCouponList:CouponList? = nil
    var filterArea:UIView? = nil
    var filterButton = UIButton()
    var tt = 10
    override init(frame: CGRect) {
        super.init(frame: frame)
        exchangeCouponList = CouponList(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height))
        exchangeCouponList!.couponListIdentifier = 1
        exchangeCouponList!.backgroundColor = .clear
        exchangeCouponList!.showValue = true
        exchangeCouponList!.showsVerticalScrollIndicator = false
        addSubview(exchangeCouponList!)
        filterArea = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 38.5 + between.height*2))
        filterArea!.backgroundColor = .invertMain
        let  path = UIBezierPath()
        let  p0 = CGPoint(x: 0, y: filterArea!.frame.height)
        path.move(to: p0)
        let  p1 = CGPoint(x: fullScreenSize.width, y: filterArea!.frame.height)
        path.addLine(to: p1)
        let dashLine = CAShapeLayer()
        dashLine.strokeColor = UIColor.main.cgColor
        dashLine.lineWidth = 1
        dashLine.lineDashPattern = [4, 4]
        dashLine.frame = bounds
        dashLine.fillColor = nil
        dashLine.path = path.cgPath
        dashLine.rasterizationScale = UIScreen.main.scale;
        dashLine.shouldRasterize = true;
        filterArea!.layer.addSublayer(dashLine)
        let filterDescription = UILabel(frame: CGRect(x: CGFloat(viewLeftLine), y: between.height*2, width: 180, height: 17))
        filterDescription.textColor = .main
        filterDescription.font = .mediSemiBold
        filterDescription.text = lang["couponCanExchange"]
        filterArea!.addSubview(filterDescription)
        filterButton.frame = CGRect(x: CGFloat(viewRightLine - 80), y: 0, width: 80, height: filterArea!.frame.height)
        filterButton.contentEdgeInsets = UIEdgeInsets(top: between.height*2 - 5, left: 0, bottom: 20, right: 0)
        filterButton.setImage(UIImage(named: "filterIcon"), for: .normal)
        filterButton.setTitle(lang["filter"], for: .normal)
        filterButton.setTitleColor(.main, for: .normal)
        filterButton.titleLabel?.font = .norm
        filterButton.contentHorizontalAlignment = .right
        filterButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 10)
        filterButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 0)
        filterArea!.addSubview(filterButton)
        addSubview(filterArea!)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func getRange() -> [Int] {
        return exchangeCouponList!.getRange()
    }
}
