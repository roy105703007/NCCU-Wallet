//
//  ViewController.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/10.
//  Copyright © 2019 徐胤桓. All rights reserved.
//
import UIKit
import Alamofire

let serverIP = "http://wm.nccu.edu.tw:3001/innerapi"
var header : HTTPHeaders!

struct UserInfo: Codable {
    var student_id: String
    var address: String
    var email: String
    var name: String
    var token: String
    var expires_in: String
}

var user = UserInfo(student_id: "", address: "", email: "", name: "", token: "", expires_in: "")

class LogInView: UIViewController, UITextFieldDelegate{
    
    struct Credentials {
        var username: String
        var password: String
    }
    struct KeychainError: Error {
        var status: OSStatus
        @available(iOS 11.3, *)
        var localizedDescription: String {
            return SecCopyErrorMessageString(status, nil) as String? ?? "Unknown error."
        }
    }
    
    let titleDeco = UIImageView(frame: CGRect(x: 0, y: 0, width: 300, height: 170))
    let IDText = UILabel()
    var IDInput:MainInput = MainInput()
    let passwordText = UILabel()
    var passwordInput:MainInput = MainInput()
    var logInBtn = MainButton(inline:2)
    var signUpBtn = MainButton(inline:2)
    var cancelReceive = false
    var idReceive: String?
    var passwordReceive: String?
    let decoShift:CGFloat = UIDevice.hasNotch ? 70 : 60
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(Locale.current.languageCode)
        titleDeco.image = UIImage.colorful(named: "loginDeco")
        titleDeco.center = CGPoint(x: fullScreenSize.width / 2, y: statusBarHeight + self.decoShift + titleDeco.frame.height/2)
        titleDeco.contentMode = .scaleAspectFit
        
        IDText.textAlignment = NSTextAlignment.left
        IDText.text = lang["loginAccountPrompt"]
        IDText.textColor = .main
        IDText.font = .norm
        IDText.frame = CGRect(x: viewLeftLine, y: Int(titleDeco.frame.origin.y + titleDeco.frame.height + between.height*2), width: Int(fullViewSize.width), height: 20)
        
        IDInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: IDText.frame.origin.y + IDText.frame.height + gutter.height)
        IDInput.placeholder = lang["loginAccountPlaceholder"]
        IDInput.delegate = self
        
        passwordText.textAlignment = NSTextAlignment.left
        passwordText.text = lang["loginPassPrompt"]
        passwordText.textColor = .main
        passwordText.font = .norm
        passwordText.frame = CGRect(x: viewLeftLine, y: Int(IDInput.frame.origin.y + IDInput.frame.height + between.height), width: Int(fullViewSize.width), height: 20)
        
        passwordInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: passwordText.frame.origin.y + passwordText.frame.height + gutter.height)
        passwordInput.placeholder = lang["loginPassPlaceholder"]
        passwordInput.isSecureTextEntry = true
        passwordInput.delegate = self
        
        logInBtn.setTitle(lang["login"], for: .normal)
        logInBtn.setTitleColor(.white, for: .normal)
        logInBtn.tag = 0
        logInBtn.titleLabel?.font = .normBold
        logInBtn.addTarget(
            self,
            action: #selector(logInBtn(_:)),
            for: .touchUpInside)
        logInBtn.frame.origin = CGPoint(x: fullScreenSize.width/2 + gutter.width/2, y: fullScreenSize.height - logInBtn.frame.height - between.height)
        
        signUpBtn.setTitle(lang["signup"], for: .normal)
        signUpBtn.setTitleColor(.white, for: .normal)
        signUpBtn.mainColor = .lightBlue
        signUpBtn.backgroundColor = .lightBlue
        signUpBtn.tag = 1
        signUpBtn.titleLabel?.font = .normBold
        signUpBtn.addTarget(
            self,
            action: #selector(goToSignUp(_:)),
            for: .touchUpInside)
        signUpBtn.frame.origin = CGPoint(x: CGFloat(viewPaddingSize), y: fullScreenSize.height - signUpBtn.frame.height - between.height)
        
        self.view.addSubview(titleDeco)
        self.view.addSubview(IDText)
        self.view.addSubview(IDInput)
        self.view.addSubview(passwordText)
        self.view.addSubview(passwordInput)
        self.view.addSubview(logInBtn)
        self.view.addSubview(signUpBtn)
        
        self.view.backgroundColor = UIColor.white
        print(idReceive)
        IDInput.text = idReceive
        passwordInput.text = passwordReceive

    }
    override func viewDidAppear(_ animated: Bool) {
        accessKeyChain()
        //IDInput.text = "108753110@nccu.edu.tw"
        //passwordInput.text = "02282040"
        if passwordInput.text != nil {
            //logInApi()
        }


    }
    @objc func goToSignUp(_ sender: UIButton){
        self.performSegue(withIdentifier: "signUpSegue", sender: sender)
    }
    @objc func logInBtn(_ sender: UIButton) {
        logInApi()
    }
    func logInApi(){
        if(IDInput.text! == ""){
            let alertController = UIAlertController(title: "帳號不得為空\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
            
        else if(passwordInput.text! == ""){
            let alertController = UIAlertController(title: "密碼不得為空\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
        let params = [
            "email": IDInput.text!,
            "password": passwordInput.text!.md5()
        ]
        
        Alamofire.request("http://wm.nccu.edu.tw:3001/innerapi/login", method: .post, parameters: params, encoding: JSONEncoding.default).responseJSON { (response) in
            print(params)
            if response.result.isSuccess {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                print(response.result.value)
                if let logInResult = response.data, let userInfo = try? decoder.decode(UserInfo.self, from: logInResult) {
                    user = userInfo
                    print(user)
                    header = ["authorization": "Bearer " + user.token]
                    //記住帳號密碼
                    /*
                    UserDefaults.standard.set(self.IDInput.text!, forKey: "ID")
                    UserDefaults.standard.set(self.passwordInput.text!, forKey: "password")
                    */
                    self.performSegue(withIdentifier: "logInSuccess", sender: nil)
                }
                //登入失敗
                if(user.token.isEmpty){
                    if let logInResult: NSDictionary = (response.result.value as! NSDictionary) {
                        let alertController = UIAlertController(title: (logInResult["msg"] as! String), message: "", preferredStyle: UIAlertController.Style.alert)
                        alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alertController, animated: true, completion: nil)
                    }
                }
            }
            else{
                let alertController = UIAlertController(title: "網路連線錯誤\n", message: "", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
                
                
            }
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let button = sender as? UIButton{
            if button.tag == 1 {
                let controller = segue.destination as? SignUpView
            }
            else if button.tag == 0 {
                let controller = segue.destination as? TabBar
            }
            
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions.curveEaseInOut, animations: {
            self.titleDeco.frame.origin.y = -self.titleDeco.frame.height
            self.titleDeco.alpha = 0
            self.IDText.frame = CGRect(x: viewLeftLine, y: Int(self.titleDeco.frame.origin.y + self.titleDeco.frame.height + between.height*2), width: Int(fullViewSize.width), height: 20)
            self.IDInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: self.IDText.frame.origin.y + self.IDText.frame.height + gutter.height)
            self.passwordText.frame = CGRect(x: viewLeftLine, y: Int(self.IDInput.frame.origin.y + self.IDInput.frame.height + between.height), width: Int(fullViewSize.width), height: 20)
            self.passwordInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: self.passwordText.frame.origin.y + self.passwordText.frame.height + gutter.height)
        }) { (true) in
            //
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions.curveEaseInOut, animations: {
            self.titleDeco.center = CGPoint(x: fullScreenSize.width / 2, y: statusBarHeight + self.decoShift + self.titleDeco.frame.height/2)
            self.titleDeco.alpha = 1
            self.IDText.frame = CGRect(x: viewLeftLine, y: Int(self.titleDeco.frame.origin.y + self.titleDeco.frame.height + between.height*2), width: Int(fullViewSize.width), height: 20)
            self.IDInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: self.IDText.frame.origin.y + self.IDText.frame.height + gutter.height)
            self.passwordText.frame = CGRect(x: viewLeftLine, y: Int(self.IDInput.frame.origin.y + self.IDInput.frame.height + between.height), width: Int(fullViewSize.width), height: 20)
            self.passwordInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: self.passwordText.frame.origin.y + self.passwordText.frame.height + gutter.height)
        }) { (true) in
            //
        }
    }
    
    func readCredentials(server: String) throws -> Credentials {
        let query: [String: Any] = [kSecClass as String: kSecClassInternetPassword,
                                    kSecAttrServer as String: server,
                                    kSecMatchLimit as String: kSecMatchLimitOne,
                                    kSecReturnAttributes as String: true,
                                    kSecUseOperationPrompt as String: "Access your password on the keychain",
                                    kSecReturnData as String: true]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess else { throw KeychainError(status: status) }
        
        guard let existingItem = item as? [String: Any],
            let passwordData = existingItem[kSecValueData as String] as? Data,
            let password = String(data: passwordData, encoding: String.Encoding.utf8),
            let account = existingItem[kSecAttrAccount as String] as? String
            else {
                throw KeychainError(status: errSecInternalError)
        }
        
        return Credentials(username: account, password: password)
    }
    
    func accessKeyChain(){
        do {
            let credentials = try self.readCredentials(server: serverIP)
            IDInput.text = credentials.username
            passwordInput.text = credentials.password
        } catch {
            if error is KeychainError {
                let keychainErrorAlert = UIAlertController(title: "keychain", message: "error.localizedDescription", preferredStyle: .alert)
                let okAction = UIAlertAction(title: "確認", style: .default, handler: nil)
                keychainErrorAlert.addAction(okAction)
                self.present(keychainErrorAlert, animated: true, completion: nil)
            }
        }
    }
}
