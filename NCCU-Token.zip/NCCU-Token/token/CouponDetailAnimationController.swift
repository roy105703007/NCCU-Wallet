//
//  CouponDetailAnimationController.swift
//  token
//
//  Created by 王瀚 on 2019/7/28.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class CouponDetailAnimationController: NSObject {
    private let animationDuration: Double
    private let animationType: AnimationType
    enum AnimationType {
        case present
        case dismiss
    }
    init(animationDuration: Double, animationType: AnimationType){
        self.animationDuration = animationDuration
        self.animationType = animationType
    }
}
extension CouponDetailAnimationController: UIViewControllerAnimatedTransitioning{
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return TimeInterval(exactly: animationDuration) ?? 0
    }
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        guard let toViewController = transitionContext.viewController(forKey: .to),
            let fromViewController = transitionContext.viewController(forKey: .from) else {
                transitionContext.completeTransition(false)
                return
        }
        switch animationType {
            case .present:
                transitionContext.containerView.addSubview(toViewController.view)
                presentAnimation(with: transitionContext, viewToAnimate: toViewController.view, viewToLeave: fromViewController.view)
            case .dismiss:
                transitionContext.containerView.addSubview(toViewController.view)
                transitionContext.containerView.addSubview(fromViewController.view)
                dismissAnimation(with: transitionContext, viewToAnimate: toViewController.view, viewToLeave: fromViewController.view)
        }
    }
    
    func dismissAnimation(with transitionContext: UIViewControllerContextTransitioning, viewToAnimate: UIView, viewToLeave: UIView){
        //viewToAnimate.transform = CGAffineTransform(scaleX: 0, y: 0)
        //viewToLeave.alpha = 1
        let duration = transitionDuration(using: transitionContext)
        UIView.animate(withDuration: duration, delay: 0, options: .curveEaseInOut, animations: {
            // viewToAnimate.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            viewToLeave.frame.origin.x = fullScreenSize.width
            //viewToLeave.alpha = 0
            viewToAnimate.frame.origin.x = 0
        }) { _ in
            transitionContext.completeTransition(true)
        }
    }
    
    func presentAnimation(with transitionContext: UIViewControllerContextTransitioning, viewToAnimate: UIView, viewToLeave: UIView){
        viewToAnimate.clipsToBounds = true
        //viewToAnimate.transform = CGAffineTransform(scaleX: 0, y: 0)
        viewToAnimate.frame.origin.x = fullScreenSize.width
        //viewToAnimate.alpha = 0
        let initViewToLeavePosition = viewToLeave.frame.origin.x
        let duration = transitionDuration(using: transitionContext)
        UIView.animate(withDuration: duration, delay: 0, options: .curveEaseInOut, animations: {
           // viewToAnimate.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            viewToAnimate.frame.origin.x = 0
            //viewToAnimate.alpha = 1
            viewToLeave.frame.origin.x = initViewToLeavePosition - fullScreenSize.width * 0.1
        }) { _ in
            transitionContext.completeTransition(true)
        }
    }
}
