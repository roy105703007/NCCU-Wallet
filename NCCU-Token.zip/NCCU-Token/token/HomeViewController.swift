//
//  HomeViewController.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/20.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import UIKit
import Alamofire

struct LogResult: Codable {
    var status: Bool
    var tx_logs: [tx_logs_info]
    struct tx_logs_info: Codable {
        var from_account: txLogUserInfo
        var to_account: txLogUserInfo
        var description: String
        var status: String
        var point: Int
        var create_date: String
        struct txLogUserInfo: Codable {
            var name: String
        }
    }
    
}

struct Point: Codable {
    var address: String     //點數地址
    var deadline: String    //點數到期日
    var name: String        //點數名稱
    var owner: String       //發行單位地址
    var unit: String        //發行單位
    var valid: Bool
    var balance: Int
}
struct PointsResult: Codable {
    var points: Int
    var status: Bool
}
func totalPointAddCommaPer3Digit() -> String {
    var hold = String(totalPoint)
    if(hold.count >= 4){
        hold.insert(",", at: hold.index(hold.startIndex, offsetBy: hold.count - 3))
    }
    return hold + " "
}
var totalPoint = 0  // 持有餘額

var pointResults = [Point]() //各點數相關參數
var logResults: LogResult?
var customLogResults: LogResult?
var couponsResults: CouponResult?
var myCouponsResults: [MyCoupon]!
let logGroup = DispatchGroup()
let logGroup2 = DispatchGroup()
let logGroup3 = DispatchGroup()

struct  MyCoupon {
    var authCode : String
    var exchangeDate : String
    var expiredDate : String
    var image : String
    var product : String
    var url : String
    var used : Bool
    var id : String
}

class HomeView: UIViewController, UIScrollViewDelegate{
    let ovRefreshControl = UIRefreshControl()
    //var ovHeaderFrame = CGRect()
    //var ovScrollViewFrame = CGRect()
    var ovHeaderFrame = CGRect()
    var ovScrollViewFrame = CGRect()
    let ovHeaderBg = UIImageView()
    let ovHeaderContent = UIImageView()
    let balanceLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 15))
    let balanceNumber = UILabel(frame: CGRect(x: 0, y: 0, width: 240, height: 45))
    let qrcodeBtn = UIButton(frame: CGRect(x: 0, y: 0, width: 47, height: 47))
    let ovScrollView  = UIScrollView()
    var lastestTransactionList: LastestTransactionTableView!
    var willExpCouponLabel : UILabel!
    var lastestTransaction : UILabel!
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
        let bnFz = fontSizeHuge - (fontSizeHuge - 30) * (1-self.balanceLabel.alpha)
        balanceNumber.multiStyle(content: [(totalPointAddCommaPer3Digit(),UIFont.systemFont(ofSize: bnFz, weight: UIFont.Weight.bold),UIColor.invertMain),("pt",UIFont.normSemiBold,UIColor.invertMain)])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print((keystoreManager!.addresses?.first!.address)!)


        // define layout
        ovHeaderFrame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: (UIDevice.hasNotch ? 220 : 198))
        ovScrollViewFrame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height)
        
        // draw view
        ovHeaderBg.frame = ovHeaderFrame
        ovHeaderContent.frame = ovHeaderFrame
        //ovHeaderBg.frame = ovHeaderFrame
        //ovHeaderContent.frame = ovScrollViewFrame
        
        ovHeaderBg.addSubview(ovHeaderContent)
        ovHeaderBg.frame.origin = CGPoint(x: 0, y: 0)
        ovHeaderBg.contentMode = .scaleAspectFill
        ovHeaderBg.clipsToBounds = false
        ovHeaderBg.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: ovHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        ovHeaderContent.contentMode = .scaleAspectFill
        ovHeaderContent.image = UIImage.colorful(named: "overviewBgPNG")
        
        balanceLabel.text = lang["balanceLabel"]
        balanceLabel.font = .normSemiBold
        balanceLabel.textColor = .invertMain
        
        balanceNumber.multiStyle(content: [("0 ",UIFont.hugeBold,UIColor.invertMain),("pt",UIFont.normSemiBold,UIColor.invertMain)])
        
        balanceLabel.frame.origin = CGPoint(x: CGFloat(viewLeftLine) + gutter.width, y: (ovHeaderFrame.height - statusBarHeight - 60 - gutter.height)/2 + statusBarHeight - gutter.height)
        
        balanceNumber.frame.origin = CGPoint(x: CGFloat(viewLeftLine) + gutter.width, y: (ovHeaderFrame.height - statusBarHeight - 60 - gutter.height)/2 + statusBarHeight + 15)
        
        qrcodeBtn.setBackgroundImage(UIImage(named: "qrcodeBtn"), for: .normal)
        qrcodeBtn.frame.origin = CGPoint(x: CGFloat(viewRightLine - 47) - gutter.width, y: (ovHeaderFrame.height - statusBarHeight - 47)/2 + statusBarHeight - gutter.height)
        
        ovScrollView.frame = ovScrollViewFrame
        ovScrollView.isUserInteractionEnabled = true
        ovScrollView.isScrollEnabled = true
        ovScrollView.contentInset = UIEdgeInsets(top: ovHeaderFrame.height - statusBarHeight, left: 0, bottom: (self.tabBarController?.tabBar.frame.size.height ?? 49.0), right: 0)
        ovScrollView.delegate = self

        ovRefreshControl.addTarget(self, action: #selector(refreshOverview), for: UIControl.Event.valueChanged)
        ovScrollView.refreshControl = ovRefreshControl
        ovScrollView.frame.origin = CGPoint(x: 0, y: 0)
        
        logGroup.enter()
        getCouponInfo()
        //getMyCouponInfo()
        logGroup.notify(queue: DispatchQueue.main, execute: {
            logGroup2.enter()
            self.willExpCouponLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: 17))
            self.willExpCouponLabel.textColor = .main
            self.willExpCouponLabel.font = .mediSemiBold
            self.willExpCouponLabel.text = lang["willExpCouponLabel"]
            self.willExpCouponLabel.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: between.height)
            self.ovScrollView.addSubview(self.willExpCouponLabel)
            
            let willExpCouponList = couponCollectionView()
            willExpCouponList.frame.origin = CGPoint(x: 0, y: self.willExpCouponLabel.frame.height + self.willExpCouponLabel.frame.origin.y + gutter.height)
            self.ovScrollView.addSubview(willExpCouponList)
            logGroup2.leave()
            
            logGroup2.notify(queue: DispatchQueue.main, execute: {
                self.lastestTransaction = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: 17))
                self.lastestTransaction.textColor = .main
                self.lastestTransaction.font = .mediSemiBold
                self.lastestTransaction.text = lang["lastestTransaction"]
                self.lastestTransaction.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: willExpCouponList.frame.height + willExpCouponList.frame.origin.y + between.height)
                self.ovScrollView.addSubview(self.lastestTransaction)
                
                logGroup3.enter()
                self.getInfo()
                logGroup3.notify(queue: DispatchQueue.main, execute: {
                    self.lastestTransactionList = LastestTransactionTableView()
                    self.lastestTransactionList.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: self.lastestTransaction.frame.height + self.lastestTransaction.frame.origin.y + gutter.height)
                    self.ovScrollView.addSubview(self.lastestTransactionList)
                    self.ovScrollView.contentSize = CGSize(width: fullScreenSize.width, height: self.lastestTransactionList.frame.origin.y + self.lastestTransactionList.frame.height + between.height)
                })
            })
        })
       
        
        

        self.view.addSubview(ovScrollView)
        self.view.addSubview(ovHeaderBg)
        self.view.addSubview(balanceLabel)
        self.view.addSubview(balanceNumber)
        self.view.addSubview(qrcodeBtn)
        self.getPointResult()
        self.view.backgroundColor = UIColor.white
    }
    //獲得點數種類
    func getPointResult(){
        Alamofire.request(serverIP + "/points", encoding: JSONEncoding.default, headers: header!).responseJSON { (response:DataResponse<Any>) in
            if response.result.isSuccess {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                print(response.result.value)
                if let result = response.data, let pointsResult = try?decoder.decode(PointsResult.self, from: result) {
                    if(pointsResult.status){
                        totalPoint = pointsResult.points
                        self.balanceNumber.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.hugeBold,UIColor.invertMain),("pt",UIFont.normSemiBold,UIColor.invertMain)])

                    }
                    else{
                        
                    }
                }
            }
            else{
                let alertController = UIAlertController(title: "網路連線錯誤\n", message: "", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    
    func getInfo(){
        let apiString = serverIP + "/tx_logs?" + "endDate=2019-12-31" + "&" + "startDate=2019-07-01" +
            "&" + "limit=0" + "&" + "skip=0"
        Alamofire.request(apiString, method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            print(response.data)
            if let apiResult = response.data, let infoResult = try?decoder.decode(LogResult.self, from: apiResult) {
                logResults = infoResult
            }
            else {
                print("error")
            }
            logGroup3.leave()
        }
    }
    
    
    func getCouponInfo(){
        Alamofire.request(serverIP + "/coupon", method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            print(response.result.value)
            if let couponResult = response.data, let couponInfoResult = try?decoder.decode(CouponResult.self, from: couponResult) {
                couponsResults = couponInfoResult

                Alamofire.request(serverIP + "/coupon/owned", method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    
                    if let ownedCoupons: NSArray = (response.result.value as! NSDictionary)["coupons"] as! NSArray  {
                        //let myCoupons = ownedCouponsResult["coupons"] as! [String:Any]
                        myCouponsResults = [MyCoupon]()
                        for item in ownedCoupons {
                            let hold = item
                            let _authCode = (hold as! NSDictionary)["authCode"] as! String
                            let _exchangeDate = (hold as! NSDictionary)["exchange_date"] as! String
                            var _expiredDate = (hold as! NSDictionary)["expiryDate"] as! String
                            let dateSeperated =   _expiredDate.components(separatedBy: " ")//seperate a fucking long timestamp from backend.
                            let timeSeperated = dateSeperated[4].components(separatedBy: ":")//separate hours, mins, secs
                            let monthHold = monthAlphaToMonthDigit(mon: dateSeperated[1] )
                            _expiredDate = dateSeperated[3] + monthHold + dateSeperated[2] + timeSeperated[0] + timeSeperated[1] + timeSeperated[2]
                            let _url = (hold as! NSDictionary)["url"] as! String
                            let _productObject = (hold as! NSDictionary)["product"] as! NSDictionary
                            let _product = _productObject["name"] as! String
                            let _image = _productObject["image"] as! String
                            let _id = _productObject["_id"] as! String
                            var _used = (hold as! NSDictionary)["used"] as! Bool
                            if(myCouponsResults.count == 1){
                                _used = true
                            }
                            myCouponsResults.append(MyCoupon(authCode: _authCode, exchangeDate: _exchangeDate, expiredDate: _expiredDate, image: _image, product: _product, url: _url, used: _used, id : _id))
                        }
                    }
                    else {
                        print("errorFromMyOwnedCoupons")
                    }
                    logGroup.leave()
                    
                }
            }
            else {
                print("errorWhere?")
            }
        }
    }
    
    @objc func refreshOverview(){
        // 這邊我們用一個延遲讀取的方法，來模擬網路延遲效果（延遲3秒）
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3) {
            // 停止 refreshControl 動畫
            let apiString = serverIP + "/tx_logs?" + "endDate=2019-12-31" + "&" + "startDate=2019-07-01" +
                "&" + "limit=0" + "&" + "skip=0"
            Alamofire.request(apiString, method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                print(response.data)
                if let apiResult = response.data, let infoResult = try?decoder.decode(LogResult.self, from: apiResult) {
                    logResults = infoResult
                    self.lastestTransactionList = LastestTransactionTableView()
                    self.lastestTransactionList.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: self.lastestTransaction.frame.height + self.lastestTransaction.frame.origin.y + gutter.height)
                    self.ovScrollView.addSubview(self.lastestTransactionList)
                    self.ovScrollView.contentSize = CGSize(width: fullScreenSize.width, height: self.lastestTransactionList.frame.origin.y + self.lastestTransactionList.frame.height + between.height)
                }
                else {
                    print("error")
                }
            }
            self.ovRefreshControl.endRefreshing()
            /*
            for _ in 1...5 {
                self.data.append(self.data.count + 1)
                self.myTableView.insertRows(at: [[0,self.data.count - 1]], with: UITableViewRowAnimation.fade)
            }
            // 滾動到最下方最新的 Data
            self.myTableView.scrollToRow(at: [0,self.data.count - 1], at: UITableViewScrollPosition.bottom, animated: true)*/
        }
        
    }

    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let y = scrollView.contentOffset.y + ovHeaderFrame.height
        let minHeight = (UIDevice.hasNotch ? 144 : 120)
        var newHeight = max((self.ovHeaderFrame.height - y), (CGFloat)(minHeight))
        self.ovHeaderContent.frame.size.height = newHeight
        if(y < 0){
            newHeight=self.ovHeaderFrame.height
        }
        self.ovHeaderBg.frame.size.height = newHeight
        ovHeaderBg.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: ovHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        self.balanceLabel.alpha = (newHeight - (CGFloat)(minHeight)) / (self.ovHeaderFrame.height - (CGFloat)(minHeight))
        let fixGutterHeight = gutter.height * -self.balanceLabel.alpha
        self.balanceLabel.frame.origin = CGPoint(x: CGFloat(viewLeftLine) + gutter.width, y: (newHeight - statusBarHeight - 60 - gutter.height)/2 + statusBarHeight - gutter.height)
        let bnShift = (1-self.balanceLabel.alpha) * (gutter.height + 15) / 2
        self.balanceNumber.frame.origin = CGPoint(x: CGFloat(viewLeftLine) + gutter.width, y: (newHeight - statusBarHeight - 60 + fixGutterHeight)/2 + statusBarHeight + 15 - bnShift)
        let bnFz = fontSizeHuge - (fontSizeHuge - 30) * (1-self.balanceLabel.alpha)
        balanceNumber.multiStyle(content: [(totalPointAddCommaPer3Digit(),UIFont.systemFont(ofSize: bnFz, weight: UIFont.Weight.bold),UIColor.invertMain),("pt",UIFont.normSemiBold,UIColor.invertMain)])
        let fixQrcodeHeight = (gutter.height - 10) * (1 - self.balanceLabel.alpha)
        self.qrcodeBtn.frame.origin = CGPoint(x: CGFloat(viewRightLine - 47) - gutter.width, y: (newHeight - statusBarHeight - 47)/2 + statusBarHeight - gutter.height + fixQrcodeHeight)
        //getInfo()
    }
}
