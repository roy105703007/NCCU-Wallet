//
//  lang.swift
//  token
//
//  Created by 王瀚 on 2019/7/22.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
let langStr = (Locale.current.languageCode ?? "zh-Hant").hasPrefix("zh") ? "zh-Hant" : "en"

let dict = [
    "balanceLabel" : [
        "zh-Hant": "我的政大點數",
        "en": "My Balance"
    ],
    "tabLabelOverview" : [
        "zh-Hant": "總覽",
        "en": "Overview"
    ],
    "tabLabelCoupon" : [
        "zh-Hant": "電子禮券",
        "en": "Coupon"
    ],
    "tabLabelTransfer" : [
        "zh-Hant": "轉帳",
        "en": "Transfer"
    ],
    "tabLabelLogs" : [
        "zh-Hant": "交易紀錄",
        "en": "Transaction"
    ],
    "tabLabelSetting" : [
        "zh-Hant": "設定",
        "en": "Setting"
    ],
    "willExpCouponLabel" : [
        "zh-Hant": "我的電子禮券",
        "en": "Coupon"
    ],
    "lastestTransaction" : [
        "zh-Hant": "近期點數交易紀錄",
        "en": "Latest Transaction"
    ],
    "transaction-ovLog" : [
        "zh-Hant": "點數轉出",
        "en": "Transaction Result"
    ],
    "income-ovLog" : [
        "zh-Hant": "收到點數",
        "en": "Income Result"
    ],
    "mybalance": [
        "zh-Hant": "我的政大點數",
        "en": "My Balance"
    ],
    "myCoupon": [
        "zh-Hant": "我的電子禮券",
        "en": "My Coupon"
    ],
    "getCoupon": [
        "zh-Hant": "兌換電子禮券",
        "en": "Get Coupon"
    ],
    "couponCanExchange": [
        "zh-Hant": "可兌換的電子禮券",
        "en": "Coupon List"
    ],
    "filter": [
        "zh-Hant": "篩選",
        "en": "Filter"
    ],
    "filterCoupons": [
        "zh-Hant": "篩選電子禮券",
        "en": "Filter Coupons"
    ],
    "filterCouponsHint": [
        "zh-Hant": "點擊並設定您想要的篩選條件",
        "en": "Set your filter condition."
    ],
    "merchantRange": [
        "zh-Hant": "商家範圍",
        "en": "Merchant Range"
    ],
    "valueRange": [
        "zh-Hant": "點數範圍",
        "en": "Price Range"
    ],
    "confirmFilter": [
        "zh-Hant": "篩選電子禮券",
        "en": "Confirm"
    ],
    "confirmPurchase": [
        "zh-Hant": "確認兌換",
        "en": "Confirm"
    ],
    "confirmPurchaseCost": [
        "zh-Hant": "需花費",
        "en": "Cost:"
    ],
    "transferAccountHint": [
        "zh-Hant": "請輸入轉入帳號(email)",
        "en": "transferAccountHint"
    ],
    "transferAccountPlaceholder": [
        "zh-Hant": "請輸入您想轉入的帳號(email)...",
        "en": "transferAccountPlaceholder"
    ],
    "or": [
        "zh-Hant": "或",
        "en": "OR"
    ],
    "transferUsingQrcode": [
        "zh-Hant": "掃描QR Code",
        "en": "Scan QR Code"
    ],
    "back": [
        "zh-Hant": "返回",
        "en": "Back"
    ],
    "scanTitle": [
        "zh-Hant": "掃描行動條碼",
        "en": "Scan QRCode"
    ],
    "scanTitleHint": [
        "zh-Hant": "請將QRCode對準方框",
        "en": "Scan QRCode"
    ],
    "openFromAlbum": [
        "zh-Hant": "從相簿打開...",
        "en": "Open from album..."
    ],
    "loginAccountPrompt": [
        "zh-Hant": "帳號(email)",
        "en": "Account(Stud ID)"
    ],
    "loginAccountPlaceholder": [
        "zh-Hant": "請輸入您的帳號(email)...",
        "en": "Please Enter Your Account..."
    ],
    "loginPassPrompt": [
        "zh-Hant": "密碼",
        "en": "Password"
    ],
    "loginPassPlaceholder": [
        "zh-Hant": "請輸入您的密碼...",
        "en": "Please Enter Your Password..."
    ],
    "inputAmountHint": [
        "zh-Hant": "請輸入您要轉出的點數",
        "en": "請輸入您要轉出的點數"
    ],
    "accountHint": [
        "zh-Hant": "您即將轉入帳號",
        "en": "您即將轉入帳號"
    ],
    "amountHint": [
        "zh-Hant": "轉出點數",
        "en": "轉出點數"
    ],
    "unitHint": [
        "zh-Hant": "點",
        "en": "pt"
    ],
    "transferWarningText": [
        "zh-Hant": "注意！按下下一步即代表您同意將點數轉讓給您指定的帳號！",
        "en": "注意！按下下一步即代表您同意將點數轉讓給您指定的帳號！"
    ],
    "next": [
        "zh-Hant": "下一步",
        "en": "Next"
    ],
    "lastWeek": [
        "zh-Hant": "近一週",
        "en": "This Week"
    ],
    "lastTwoWeek": [
        "zh-Hant": "近兩週",
        "en": "2 Weeks"
    ],
    "lastMonth": [
        "zh-Hant": "近一個月",
        "en": "1 Month"
    ],
    "custom": [
        "zh-Hant": "自訂",
        "en": "Customize"
    ],
    "pleaseKeyPassword": [
        "zh-Hant":"請輸入密碼",
        "en": "please enter the password"
    ],
    "keyPasswordHolder": [
        "zh-Hant":"請輸入您的密碼...",
        "en":"please enter your password..."
    ],
    "cancel": [
        "zh-Hant":"取消",
        "en":"Cancel"
    ],
    "login": [
        "zh-Hant":"登入",
        "en":"Login"
    ],
    "signup": [
        "zh-Hant":"註冊",
        "en":"SignUp"
    ]
]
let lang = Dictionary(uniqueKeysWithValues: dict.map{($0.0, $0.1[langStr]!)})
