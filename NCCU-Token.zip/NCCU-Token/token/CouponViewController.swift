//
//  File.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/20.
//  Copyright © 2019 徐胤桓. All rights reserved.
//
import UIKit
protocol CouponSegmentContainerDelegate{
    func onPageChange(currentPage: Int)
    func switchTab(to: Int)
    func couponListScroll(_ scrollView: UIScrollView, from: Int)
    func pageChaging(per: CGFloat)
    func startChanging(_ scrollView: UIScrollView)
}
public protocol GetFilterDetailDelegate {
    func getDetail(selected: [String], range: [Int])
}
class CouponView: UIViewController,CouponSegmentContainerDelegate{
    let chFrame = CGRect(x: 0, y: 0, width: fullScreenSize.width, height: (UIDevice.hasNotch ? 173 : 161))
    var couponHeaderView:CouponHeaderView? = nil
    var couponSegmentContainer:CouponSegmentContainer? = nil
    let couponView = self
    var startOffset:CGFloat = 0.0
    var startOffsetEX:CGFloat = 0.0
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
        couponHeaderView!.setup()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        couponHeaderView=CouponHeaderView(frame: chFrame)
        couponHeaderView!.dele = self
        couponSegmentContainer = CouponSegmentContainer(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height))
        couponSegmentContainer!.dele = self
        couponSegmentContainer!.myCouponView!.couponList!.contentInset = UIEdgeInsets(top: couponHeaderView!.frame.height - statusBarHeight + between.height, left: 0, bottom: (self.tabBarController?.tabBar.frame.size.height ?? 49.0), right: 0)
        couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.contentInset = UIEdgeInsets(top: couponHeaderView!.frame.height + couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.height - between.height - statusBarHeight + between.height, left: 0, bottom: (self.tabBarController?.tabBar.frame.size.height ?? 49.0), right: 0)
        couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.origin = CGPoint(x: 0, y: couponHeaderView!.frame.height - between.height)
        couponSegmentContainer!.myCouponView!.couponList!.scrollToRow(at: IndexPath(row: 0, section: 0), at: UITableView.ScrollPosition.top, animated: false)
        couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.scrollToRow(at: IndexPath(row: 0, section: 0), at: UITableView.ScrollPosition.top, animated: false)
        self.view.addSubview(couponSegmentContainer!)
        self.view.addSubview(couponHeaderView!)
        self.view.backgroundColor = UIColor.white
        couponSegmentContainer!.exchangeCouponView!.filterButton.addTarget(self, action: #selector(showFilterModal), for: .touchUpInside)
        
    }
    func onPageChange(currentPage: Int) {
        couponHeaderView!.couponSegControl.switchTo(index: currentPage)
        print(currentPage)
        if(currentPage == 0){
            couponSegmentContainer!.myCouponView!.couponList!.getCouponInfo()
        }
        else{
            couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.getCouponInfo()
        }

    }
    func pageChaging(per: CGFloat){
        if(couponSegmentContainer!.currentIndex == 0){
            let offset = (1-min(per*2,1)) * (startOffset) - chFrame.height - between.height
            couponSegmentContainer!.myCouponView!.couponList!.setContentOffset(CGPoint(x: 0.0, y: offset), animated: false)
        }else{
            let p = 1 - per
            let offset = (1-min(p*2,1)) * (startOffsetEX) - chFrame.height - between.height - couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.height + between.height
            couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.setContentOffset(CGPoint(x: 0.0, y: offset), animated: false)
        }
    }
    func startChanging(_ scrollView: UIScrollView){
        startOffset = couponSegmentContainer!.myCouponView!.couponList!.contentOffset.y + chFrame.height + between.height
        startOffsetEX = couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.contentOffset.y + chFrame.height + between.height + couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.height - between.height
    }
    func switchTab(to: Int){
        //startOffset = 0
        couponSegmentContainer!.switchToPage(to: to)
        if(to == 0){
            couponSegmentContainer!.myCouponView!.couponList!.getCouponInfo()
        }
        else{
            couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.getCouponInfo()
        }

    }
    func couponListScroll(_ scrollView: UIScrollView, from: Int) {
        if(from == 0 && couponSegmentContainer!.currentIndex == 0){
            let y = scrollView.contentOffset.y + chFrame.height + between.height
            var newHeight = max(chFrame.height - 60,chFrame.height - y)
            if(y < 0){
                newHeight = chFrame.height
            }
            couponHeaderView!.frame.size.height = newHeight
            couponHeaderView!.couponHeaderContent.frame.size.height = newHeight
            couponHeaderView!.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: couponHeaderView!.couponHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
            couponHeaderView!.norm()
        }else if(from == 1 && couponSegmentContainer!.currentIndex == 1){
            print(couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.height)
            let y = scrollView.contentOffset.y + chFrame.height + couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.height
            var newHeight = max(chFrame.height - 60,chFrame.height - y)
            if(y < 0){
                newHeight = chFrame.height
            }
            couponHeaderView!.frame.size.height = newHeight
            couponHeaderView!.couponHeaderContent.frame.size.height = newHeight
            couponHeaderView!.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: couponHeaderView!.couponHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
            couponSegmentContainer!.exchangeCouponView!.filterArea!.frame.origin.y = newHeight - between.height
            couponHeaderView!.norm()
        }else{
            print(from)
            print(couponSegmentContainer!.currentIndex)
        }
    }
    @objc func showFilterModal(){
        
        let hold : [Int] = couponSegmentContainer!.exchangeCouponView!.getRange()
        print(hold)
        FilterModal.shared.showOverlay(range: hold, dele: self)
    }
}
extension CouponView : GetFilterDetailDelegate {
    func getDetail(selected: [String], range: [Int]){
        couponSegmentContainer!.exchangeCouponView!.exchangeCouponList!.filterData(selected: selected, range: range)
        print(selected, range)
        
    }

}
