//
//  GlobalVar.swift
//  token
//
//  Created by 王瀚 on 2019/7/21.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit

let viewPaddingSize = 15 // padding
let fullScreenSize = UIScreen.main.bounds.size
let fullViewSize = CGSize(width: UIScreen.main.bounds.size.width - (CGFloat(viewPaddingSize)*2), height: UIScreen.main.bounds.size.height)
let viewLeftLine = viewPaddingSize
let viewRightLine = fullScreenSize.width - CGFloat(viewPaddingSize)
let viewCenterPoint = CGPoint(x: fullScreenSize.width * 0.5, y: fullScreenSize.height * 0.5)
let gutter = CGSize(width: 15, height: 15)
let between = CGSize(width: 15, height: 30)
let cornerRadius = 8
let inputPadding = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
let statusBarHeight = UIApplication.shared.statusBarFrame.height

// font size
let fontSizeSmall: CGFloat = 10.0
let fontSizeNorm: CGFloat = 15.0
let fontSizeMedi: CGFloat = 17.0
let fontSizeBig: CGFloat = 20.0
let fontSizeHuge: CGFloat = 40.0

// devices
extension UIDevice {
    static var hasNotch: Bool {
        if #available(iOS 11.0, *) {
            return UIApplication.shared.keyWindow?.safeAreaInsets.bottom ?? 0 > 0
        }
        return false
    }
}
// useful extension

extension UIFont{
    static var small: UIFont {
        return systemFont(ofSize: fontSizeSmall)
    }
    static var norm: UIFont {
        return systemFont(ofSize: fontSizeNorm)
    }
    static var medi: UIFont {
        return systemFont(ofSize: fontSizeMedi)
    }
    static var big: UIFont {
        return systemFont(ofSize: fontSizeBig)
    }
    static var huge: UIFont {
        return systemFont(ofSize: fontSizeHuge)
    }
    static var smallSemiBold: UIFont {
        return systemFont(ofSize: fontSizeHuge, weight: UIFont.Weight.semibold)
    }
    static var normSemiBold: UIFont {
        return systemFont(ofSize: fontSizeNorm, weight: UIFont.Weight.semibold)
    }
    static var mediSemiBold: UIFont {
        return systemFont(ofSize: fontSizeMedi, weight: UIFont.Weight.semibold)
    }
    static var bigSemiBold: UIFont {
        return systemFont(ofSize: fontSizeBig, weight: UIFont.Weight.semibold)
    }
    static var hugeSemiBold: UIFont {
        return systemFont(ofSize: fontSizeHuge, weight: UIFont.Weight.semibold)
    }
    static var smallBold: UIFont {
        return systemFont(ofSize: fontSizeHuge, weight: UIFont.Weight.bold)
    }
    static var normBold: UIFont {
        return systemFont(ofSize: fontSizeNorm, weight: UIFont.Weight.bold)
    }
    static var mediBold: UIFont {
        return systemFont(ofSize: fontSizeMedi, weight: UIFont.Weight.bold)
    }
    static var bigBold: UIFont {
        return systemFont(ofSize: fontSizeBig, weight: UIFont.Weight.bold)
    }
    static var hugeBold: UIFont {
        return systemFont(ofSize: fontSizeHuge, weight: UIFont.Weight.bold)
    }
}

extension StringProtocol where Self: RangeReplaceableCollection {
    mutating func insert(separator: Self, every n: Int) {
        for index in indices.reversed() where index != startIndex &&
            distance(from: startIndex, to: index) % n == 0 {
                insert(contentsOf: separator, at: index)
        }
    }
    
    func inserting(separator: Self, every n: Int) -> Self {
        var string = self
        string.insert(separator: separator, every: n)
        return string
    }
}

extension UILabel {
    func multiStyle(content: [(String,UIFont,UIColor)]){
        let atxt = NSMutableAttributedString(string: content[0].0, attributes: [NSAttributedString.Key.font: content[0].1,NSAttributedString.Key.foregroundColor: content[0].2])
        let elseContent = content.dropFirst()
        for (str,fnt,clr) in elseContent{
            atxt.append(NSAttributedString(string: str, attributes: [NSAttributedString.Key.font: fnt, NSAttributedString.Key.foregroundColor: clr]))
        }
        attributedText = atxt
    }
}

extension CALayer{
    func addShadow(radius: CGFloat, opacity: Float, offset: CGSize = CGSize(width: 0,height: 0)){
        shadowOffset = offset
        shadowOpacity = opacity
        shadowRadius = radius
        shadowColor = UIColor.black.cgColor
        shouldRasterize = true
        rasterizationScale = 1
    }
    func norm(){
        rasterizationScale = UIScreen.main.scale;
        shouldRasterize = true;
        contentsScale = UIScreen.main.scale
    }
}

extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat, content: UIView, shadowRadius: CGFloat? = nil, shadowOpacity: Float? = nil, borderColor: UIColor? = nil, borderWidth: CGFloat? = 1) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.frame = bounds
        mask.path = path.cgPath
        if((shadowRadius) != nil){
            layer.shadowOffset = CGSize(width: 0,height: 0)
            layer.shadowOpacity = shadowOpacity!
            layer.shadowRadius = shadowRadius!
            layer.shadowColor = UIColor.black.cgColor
            layer.shadowPath = mask.path
            layer.shouldRasterize = true
            layer.rasterizationScale = 1
        }
        if((borderColor) != nil){
            mask.strokeColor = borderColor!.cgColor
            mask.lineWidth = borderWidth!
        }
        content.layer.mask = mask
    }
    func addShadow(radius: CGFloat, opacity: Float){
        layer.shadowOffset = CGSize(width: 0,height: 0)
        layer.shadowOpacity = opacity
        layer.shadowRadius = radius
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowPath = UIBezierPath(rect: bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = 1
        clipsToBounds = false
    }
    func addDashBorder(color: UIColor, width: CGFloat? = 1, dash: [NSNumber]? = [4, 4]){
        let yourViewBorder = CAShapeLayer()
        yourViewBorder.strokeColor = color.cgColor
        yourViewBorder.lineWidth = width ?? 1
        yourViewBorder.lineDashPattern = dash
        yourViewBorder.frame = bounds
        yourViewBorder.fillColor = nil
        yourViewBorder.path = UIBezierPath(rect: bounds).cgPath
        yourViewBorder.rasterizationScale = UIScreen.main.scale;
        yourViewBorder.shouldRasterize = true;
        layer.contentsScale = UIScreen.main.scale
        layer.addSublayer(yourViewBorder)
    }
    func norm(){
        layer.rasterizationScale = UIScreen.main.scale;
        layer.shouldRasterize = true;
        layer.contentsScale = UIScreen.main.scale
    }
}

extension UIImageView {
    func downloaded(from url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func downloaded(from link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {  // for swift 4.2 syntax just use ===> mode: UIView.ContentMode
        guard let url = URL(string: link) else { return }
        downloaded(from: url, contentMode: mode)
    }
}

extension UIImage {
    static func colorful(named: String) -> UIImage{
        let context = CIContext(options: nil)
        let uii = UIImage(named: named)
        var cgi = uii!.cgImage
        let ciimage = CIImage(cgImage: cgi!)
        let filter = CIFilter(name: "CIColorControls")
        filter!.setValue(ciimage, forKey: kCIInputImageKey)
        filter!.setValue(1.3, forKey: kCIInputSaturationKey)
        let result = filter!.value(forKey: kCIOutputImageKey)
        let cgImage = context.createCGImage(result as! CIImage, from: (result as! CIImage).extent)
        let image = UIImage(cgImage: cgImage!)
        return image;
    }
}

extension UIColor {
    
    func lighter(by percentage: CGFloat = 30.0) -> UIColor? {
        return self.adjust(by: abs(percentage) )
    }
    
    func darker(by percentage: CGFloat = 30.0) -> UIColor? {
        return self.adjust(by: -1 * abs(percentage) )
    }
    
    func adjust(by percentage: CGFloat = 30.0) -> UIColor? {
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        if self.getRed(&red, green: &green, blue: &blue, alpha: &alpha) {
            return UIColor(red: min(red + percentage/100, 1.0),
                           green: min(green + percentage/100, 1.0),
                           blue: min(blue + percentage/100, 1.0),
                           alpha: alpha)
        } else {
            return nil
        }
    }
}

func moneyToString(_ money: Int) -> String {
    let formatter = NumberFormatter()
    formatter.numberStyle = .currency
    return formatter.string(from: NSNumber(value: money)) ?? "0"
}

//for api
struct CouponResult: Codable {
    var status: Bool
    var coupons: [coupons_info]
    struct product_info: Codable {
        var name: String
        var point: Int
        var image: String
        var _id: String
    }
    struct coupons_info: Codable {
        var product: product_info
        var count: Int
    }
}
struct CouponOwnedResult: Codable {
    var status: Bool
    var coupons: [coupons_info]
    struct coupons_info: Codable {
        var __v: String
        var _id: String
        var authCode: String
        var awardedAccount: String
        var exchange_date: String
        var expiryDate: String
        var image: String
        var product: String
        var url: String
        var used: String
    }
}
func monthAlphaToMonthDigit(mon: String) -> String{
    if(mon == "Jan"){
        return "01"
    }
    else if(mon == "Feb"){
        return "02"
    }
    else if(mon == "Mar"){
        return "03"
    }
    else if(mon == "Apr"){
        return "04"
    }
    else if(mon == "May"){
        return "05"
    }
    else if(mon == "Jun"){
        return "06"
    }
    else if(mon == "Jul"){
        return "07"
    }
    else if(mon == "Aug"){
        return "08"
    }
    else if(mon == "Sep"){
        return "09"
    }
    else if(mon == "Oct"){
        return "10"
    }
    else if(mon == "Nov"){
        return "11"
    }
    else if(mon == "Dec"){
        return "12"
    }
    else{
        return "00"
    }
    
}
func stringConvertDate(string:String, dateFormat:String="yyyy-MM-dd HH:mm:ss") -> Date {
    let dateFormatter = DateFormatter.init()
    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
    var dateString = ""
    var dicString = string.split(separator: "T")
    if dicString.count == 2 {
        var dicString2 = dicString[1].split(separator: ".")
        dateString = dicString[0] + " " + dicString2[0]
    }
    let date = dateFormatter.date(from: dateString)
    return date!
}
