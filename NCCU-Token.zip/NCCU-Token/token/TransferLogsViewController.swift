//
//  File.swift
//  token
//
//  Created by 徐胤桓 on 2019/7/20.
//  Copyright © 2019 徐胤桓. All rights reserved.
//
import UIKit
import Alamofire


class TransferLogsView: UIViewController{
    
    var transferLogsTableView = TransferLogsTableView()
    var transferLogsTableViewTwo = TransferLogsTableViewTwo()
    var transferLogsTableViewThree = TransferLogsTableViewThree()
    var transferLogsTableViewCustomize = TransferLogsTableViewCustomize()
    let customeSearch = UIView(frame: CGRect(x: 0, y: 150, width: fullScreenSize.width, height: 650))
    var startLabel:UILabel? = nil
    var endLabel:UILabel? = nil
    var keyLabel:UILabel? = nil
    var keyInput:MainInput = MainInput()
    var startDatePicker: UIDatePicker!
    var endDatePicker: UIDatePicker!
    var searchBtn = MainButton()
    let customGroup = DispatchGroup()
    var startString: String = ""
    var endString: String = ""
    
    
    let privateKeyLabel = UILabel(frame: CGRect(x: 0, y: fullScreenSize.height/2 - 30, width: fullScreenSize.width, height: 30))
    let keyInButton = UIButton(frame: CGRect(x: 0, y: fullScreenSize.height/2 - 60, width: fullScreenSize.width, height: 30))
    let durationSwitcherBar = UIView(frame: CGRect(x: 0, y: (UIDevice.hasNotch ? 173 : 161) - 55, width: fullScreenSize.width/4, height: 55))
    var balanceLabel:UILabel? = nil
    var balanceNum:UILabel? = nil
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
        balanceNum!.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .darkRed),("pt", UIFont.medi, .lightBlue)])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        
        startLabel = UILabel(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 40))
        startLabel!.font = .norm
        startLabel!.textColor = .gray
        startLabel!.text = "開始日期"
        
        startDatePicker = UIDatePicker(frame: CGRect(x: 0, y: 40, width: fullScreenSize.width, height: 120))
        startDatePicker.datePickerMode = .date
        startDatePicker.date = Date()
        startDatePicker.addTarget(
            self,
            action: #selector(startDatePickerChanged),
            for: .valueChanged)
        
        endLabel = UILabel(frame: CGRect(x: 0, y: 160, width: fullScreenSize.width, height: 40))
        endLabel!.font = .norm
        endLabel!.textColor = .gray
        endLabel!.text = "結束日期"
        
        endDatePicker = UIDatePicker(frame: CGRect(x: 0, y: 200, width: fullScreenSize.width, height: 120))
        endDatePicker.datePickerMode = .date
        endDatePicker.date = Date()
        endDatePicker.addTarget(
            self,
            action: #selector(endDatePickerChanged),
            for: .valueChanged)
        
        searchBtn.setTitle("搜尋", for: .normal)
        searchBtn.setTitleColor(.white, for: .normal)
        searchBtn.tag = 0
        searchBtn.isEnabled = true
        searchBtn.titleLabel?.font = .normBold
        searchBtn.addTarget(
            self,
            action: #selector(searchBtn(_:)),
            for: .touchUpInside)
        searchBtn.frame.origin = CGPoint(x: fullScreenSize.width/2 - searchBtn.frame.width/2, y: 320)
        
        customeSearch.addSubview(startLabel!)
        customeSearch.addSubview(startDatePicker)
        customeSearch.addSubview(endLabel!)
        customeSearch.addSubview(endDatePicker)
        customeSearch.addSubview(searchBtn)
        
       // privateKeyLabel.text = receivePrivateKey
        privateKeyLabel.textColor = UIColor.black
        privateKeyLabel.textAlignment = .center
        //self.view.addSubview(privateKeyLabel)
        keyInButton.setTitle("輸入密碼", for: .normal)
        keyInButton.setTitleColor(UIColor.white, for: .normal)
        keyInButton.isEnabled = true
        keyInButton.backgroundColor = UIColor.black
        keyInButton.addTarget(self, action: #selector(askPrivateKey), for: .touchUpInside)
        //self.view.addSubview(keyInButton)
        let transferLogHeader = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: (UIDevice.hasNotch ? 173 : 161)))
        let transferLogHeaderContent = UIView(frame: transferLogHeader.frame)
        transferLogHeaderContent.backgroundColor = .invertMain
        transferLogHeader.addSubview(transferLogHeaderContent)
        transferLogHeader.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: transferLogHeaderContent, shadowRadius: 50, shadowOpacity: 0.15)
        
        balanceLabel = UILabel(frame: CGRect(x: viewLeftLine + Int(gutter.width), y: Int(statusBarHeight) + Int(between.height) - (UIDevice.hasNotch ? 15 : 10), width: 100, height: 40))
        balanceLabel!.font = .norm
        balanceLabel!.textColor = .gray
        balanceLabel!.text = lang["mybalance"]
        transferLogHeaderContent.addSubview(balanceLabel!)
        
        balanceNum = UILabel(frame: CGRect(x: 0, y: 0, width: fullViewSize.width - gutter.width * 2 - balanceLabel!.frame.width, height: 40))
        balanceNum!.multiStyle(content: [(totalPointAddCommaPer3Digit(), UIFont.systemFont(ofSize: 28, weight: UIFont.Weight.bold), .main),("pt", UIFont.medi, .lightBlue)])
        balanceNum!.textAlignment = .right
        balanceNum!.frame.origin = CGPoint(x: viewRightLine - gutter.width - balanceNum!.frame.width, y: statusBarHeight + between.height - (UIDevice.hasNotch ? 15 : 10))
        transferLogHeaderContent.addSubview(balanceNum!)
        
        let durationSwitcher = UISegmentedControl(items: [lang["lastWeek"]!,lang["lastTwoWeek"]!,lang["lastMonth"]!,lang["custom"]!])
        durationSwitcher.frame = CGRect(x: 0, y: (UIDevice.hasNotch ? 173 : 161) - 55, width: fullScreenSize.width, height: 55)
        durationSwitcher.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.main, NSAttributedString.Key.font: UIFont.normBold], for: UIControl.State.selected)
        durationSwitcher.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.lightGray, NSAttributedString.Key.font: UIFont.norm], for: UIControl.State.normal)
        durationSwitcher.backgroundColor = .clear
        durationSwitcher.tintColor = .clear
        durationSwitcher.addTarget(self, action: #selector(onChange), for: .allEvents)
        
        let durationSwitcherMask = UIView(frame: CGRect(x: 0, y: (UIDevice.hasNotch ? 173 : 161) - 55, width: fullScreenSize.width, height: 53))
        let durationSwitcherMaskContent = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 53))
        durationSwitcherMask.addSubview(durationSwitcherMaskContent)
        durationSwitcherMaskContent.backgroundColor = .bgColor
        durationSwitcherMask.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 26.0, content: durationSwitcherMaskContent)
        
        durationSwitcherBar.backgroundColor = .main
        
        transferLogHeaderContent.addSubview(durationSwitcherBar)
        transferLogHeaderContent.addSubview(durationSwitcherMask)
        transferLogHeaderContent.addSubview(durationSwitcher)
        
        transferLogHeader.norm()
        durationSwitcher.selectedSegmentIndex = 0
        
        //let transferLogsTableView = TransferLogsTableView()
        transferLogsTableView = TransferLogsTableView()
        transferLogsTableView.frame.origin = CGPoint(x: 0, y: transferLogHeader.frame.height)
        transferLogsTableViewTwo = TransferLogsTableViewTwo()
        transferLogsTableViewTwo.frame.origin = CGPoint(x: 0, y: transferLogHeader.frame.height)
        transferLogsTableViewThree = TransferLogsTableViewThree()
        transferLogsTableViewThree.frame.origin = CGPoint(x: 0, y: transferLogHeader.frame.height)
        transferLogsTableViewCustomize = TransferLogsTableViewCustomize()
        transferLogsTableViewCustomize.frame.origin = CGPoint(x: 0, y: transferLogHeader.frame.height)
        self.view.addSubview(transferLogsTableView)
        self.view.addSubview(transferLogsTableViewTwo)
        self.view.addSubview(transferLogsTableViewThree)
        self.view.addSubview(transferLogsTableViewCustomize)
        self.view.addSubview(transferLogHeader)
        self.view.addSubview(customeSearch)
        customeSearch.isHidden = true
        transferLogsTableViewTwo.isHidden = true
        transferLogsTableViewThree.isHidden = true
        transferLogsTableViewCustomize.isHidden = true
    }
    
    @objc func onChange(sender: UISegmentedControl) {
        /*
        if sender.selectedSegmentIndex != 0 {
            transferLogsTableView.isHidden = true
        }*/
        if sender.selectedSegmentIndex == 0 {
            transferLogsTableView.isHidden = false
            transferLogsTableViewTwo.isHidden = true
            transferLogsTableViewThree.isHidden = true
            transferLogsTableViewCustomize.isHidden = true
            customeSearch.isHidden = true
        }
        if sender.selectedSegmentIndex == 1 {
            transferLogsTableView.isHidden = true
            transferLogsTableViewTwo.isHidden = false
            transferLogsTableViewThree.isHidden = true
            transferLogsTableViewCustomize.isHidden = true
            customeSearch.isHidden = true
        }
        if sender.selectedSegmentIndex == 2 {
            transferLogsTableView.isHidden = true
            transferLogsTableViewTwo.isHidden = true
            transferLogsTableViewThree.isHidden = false
            transferLogsTableViewCustomize.isHidden = true
            customeSearch.isHidden = true
        }
        if sender.selectedSegmentIndex == 3 {
            transferLogsTableView.isHidden = true
            transferLogsTableViewTwo.isHidden = true
            transferLogsTableViewThree.isHidden = true
            transferLogsTableViewCustomize.isHidden = true
            customeSearch.isHidden = false
        }
        UIView.animate(withDuration: 0.3) {
            self.durationSwitcherBar.frame.origin = CGPoint(x: fullScreenSize.width/4*CGFloat(sender.selectedSegmentIndex), y: (UIDevice.hasNotch ? 173 : 161) - 55)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //privateKeyLabel.text = receivePrivateKey
        privateKeyLabel.textColor = UIColor.black
        privateKeyLabel.textAlignment = .center
        self.view.addSubview(privateKeyLabel)
    }
    @objc func askPrivateKey(){
        //present(KeyInPasswordViewController(), animated: true, completion: nil)
    }
    
    @objc func searchBtn(_ sender: UIButton) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        customGroup.enter()
        getInfo()
        customGroup.notify(queue: DispatchQueue.main, execute: {
            self.customeSearch.isHidden = true
            self.transferLogsTableViewCustomize.removeFromSuperview()
            self.transferLogsTableViewCustomize = TransferLogsTableViewCustomize()
            self.transferLogsTableViewCustomize.frame.origin = CGPoint(x: 0, y: (UIDevice.hasNotch ? 173 : 161))
            self.transferLogsTableViewCustomize.isHidden = false
            self.view.addSubview(self.transferLogsTableViewCustomize)
        })
    }
    
    @objc func startDatePickerChanged(datePicker:UIDatePicker) {
        // 設置要顯示在 UILabel 的日期時間格式
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.startString = formatter.string(from: datePicker.date)
    }
    
    @objc func endDatePickerChanged(datePicker:UIDatePicker) {
        // 設置要顯示在 UILabel 的日期時間格式
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        self.endString = formatter.string(from: datePicker.date)
    }
    
    func getInfo(){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        if startString.isEmpty {
            self.startString = formatter.string(from: Date())
        }
        if endString.isEmpty {
            self.endString = formatter.string(from: Date())
        }
        
        let apiString = serverIP + "/tx_logs?" + "endDate=" + endString + "&" + "startDate=" + startString + "&" + "limit=0" + "&" + "skip=0"
        Alamofire.request(apiString, method: .get, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            if let apiResult = response.data, let infoResult = try?decoder.decode(LogResult.self, from: apiResult) {
                customLogResults = infoResult
                //self.lastestTransactionList.reloadData()
            }
            else {
                print("error")
            }
            self.customGroup.leave()
        }
    }
}
