//
//  TransferAmountController.swift
//  token
//
//  Created by 王瀚 on 2019/8/9.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import web3swift
import BigInt


protocol DismissBackDelegate {
    func dismissBack(pwd: String, cancel: Bool)
}

class TransferAmountController:UIViewController {
    struct TransferResult: Codable {
        var info: String
        var status: Int
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.default
    }
    struct ToUserInfo: Codable {
        var ID: String
        var address: String
        var name: String
    }
    struct toResult: Codable {
        struct Inf: Codable {
            var ID: String
            var address: String
            var name: String
        }
        var type: Bool
        var inf: Inf
    }
    var delegate: UpdateTotalPointDelegate?
    var cancelReceive: Bool?
    var passwordReceive: String! = "Password"
    var account = ""
    let inputAmountHint = UILabel()
    let accountHint = UILabel()
    let accountDisplay = UILabel()
    let amountHint = UILabel()
    let amountInput = MainInput()
    let unitHint = UILabel()
    let warningText = UILabel()
    let nextBtn = MainButton()
    let backButton = UIButton(frame: CGRect(x: 0, y: statusBarHeight, width: 188, height: 44))
    let updateBtn = MainButton()
    var nonce = 0
    var totalTransferValue = 0 // total value you want to transfer
    var transferCount = 0 // one value need to be seperated to many transaction
    var pointToUse = 0 // which point to use in this seperated transaction
    var password = ""
    var privateKey: Data = Data()
    var toAddress: String? = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .bgColor
        
        backButton.backgroundColor = .clear
        backButton.setImage(UIImage(named: "backIcon")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate), for: .normal)
        backButton.setTitle(lang["back"], for: .normal)
        backButton.setTitleColor(.main, for: .normal)
        backButton.tintColor = .main
        backButton.contentMode = .left
        backButton.imageView?.contentMode = .scaleAspectFit
        backButton.contentHorizontalAlignment = .left
        backButton.imageEdgeInsets = UIEdgeInsets(top: 12, left: 0, bottom: 12, right: -5)
        backButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: -8, bottom: 0, right: 0)
        backButton.addTarget(self, action: #selector(self.onDismiss), for: .touchUpInside)
        view.addSubview(backButton)

        inputAmountHint.frame = CGRect(x: 0, y: backButton.frame.origin.y + backButton.frame.height + between.height, width: fullScreenSize.width, height: 22)
        inputAmountHint.textColor = .main
        inputAmountHint.font = .bigBold
        inputAmountHint.textAlignment = .center
        inputAmountHint.text = lang["inputAmountHint"]
        view.addSubview(inputAmountHint)
        
        accountHint.frame = CGRect(x: 0, y: inputAmountHint.frame.origin.y + inputAmountHint.frame.height + between.height, width: fullScreenSize.width, height: 15)
        accountHint.font = .norm
        accountHint.textColor = .gray
        accountHint.textAlignment = .center
        accountHint.text = lang["accountHint"]
        view.addSubview(accountHint)
        
        accountDisplay.frame = CGRect(x: 0, y: accountHint.frame.origin.y + accountHint.frame.height + gutter.height, width: fullScreenSize.width, height: 15)
        accountDisplay.font = .normBold
        accountDisplay.textColor = .main
        accountDisplay.textAlignment = .center
        view.addSubview(accountDisplay)
        
        amountHint.frame = CGRect(x: CGFloat(viewLeftLine), y: accountDisplay.frame.origin.y + accountDisplay.frame.height + between.height * 2, width: fullViewSize.width, height: 15)
        amountHint.font = .norm
        amountHint.textColor = .main
        amountHint.text = lang["amountHint"]
        view.addSubview(amountHint)
        
        amountInput.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: amountHint.frame.origin.y + amountHint.frame.height + gutter.height)
        amountInput.font = .medi
        amountInput.placeholder = "0"
        amountInput.keyboardType = .numberPad
        amountInput.frame.size.height = 50
        unitHint.frame = CGRect(x: 0, y: 0, width: 22, height: 15)
        unitHint.font = .norm
        unitHint.textColor = .main
        unitHint.text = lang["unitHint"]
        unitHint.sizeToFit()
        unitHint.frame.size.height = 50
        unitHint.frame.size.width += 10
        amountInput.rightView = unitHint
        amountInput.rightViewMode = .always
        view.addSubview(amountInput)
        
        warningText.frame = CGRect(x: CGFloat(viewLeftLine) + gutter.width, y: amountInput.frame.origin.y + amountInput.frame.height + gutter.height, width: fullViewSize.width - gutter.width * 2, height: 80)
        warningText.text = lang["transferWarningText"]
        warningText.font = .norm
        warningText.textColor = .red
        warningText.lineBreakMode = .byWordWrapping
        warningText.numberOfLines = 0
        warningText.sizeToFit()
        view.addSubview(warningText)
        
        nextBtn.setTitle(lang["next"], for: UIControl.State.normal)
        nextBtn.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: fullScreenSize.height - nextBtn.frame.height - between.height)
        nextBtn.addTarget(
            self,
            action: #selector(getPassword(_:)),
            for: .touchUpInside)
        view.addSubview(nextBtn)
        
        updateBtn.setTitle(lang["up"], for: UIControl.State.normal)
        updateBtn.frame.origin = CGPoint(x: CGFloat(viewLeftLine), y: 700)
       /* updateBtn.addTarget(
            self,
            action: #selector(self.updateTotalPoint),
            for: .touchUpInside)
         view.addSubview(updateBtn)*/
        
        //getAddress()
        print(passwordReceive)
        
    }
    @objc func getPassword(_ sender: UIButton){
        for i in 0...amountInput.text!.count - 1{
            let index = amountInput.text!.index(amountInput.text!.startIndex, offsetBy: i)
            let lastChar: Character = amountInput.text![index]
            if(!lastChar.isNumber){
                let alertController = UIAlertController(title: "轉帳金額需為正整數\n", message: "", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
                return
            }
        }
        totalTransferValue = Int(amountInput.text!)!
        let firstIndex = amountInput.text!.index(amountInput.text!.startIndex, offsetBy: 0)
        if(amountInput.text![firstIndex] == "0"){
            let alertController = UIAlertController(title: "轉帳金額需為正整數\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        else if(totalPoint < totalTransferValue){
            let alertController = UIAlertController(title: "餘額不足\n", message: "", preferredStyle: UIAlertController.Style.alert)
            alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            return
        }
        else{
            var topController = UIApplication.shared.keyWindow?.rootViewController
            while ((topController?.presentedViewController) != nil) {
                topController = topController?.presentedViewController;
            }
            let tac = KeyInPasswordViewController()
            tac.modalPresentationStyle = UIModalPresentationStyle.custom
            tac.delegate = self
            topController?.present(tac, animated: true, completion: nil)
            return
            
        }
        //performSegue(withIdentifier: "transferGetPassword", sender: sender)
        
    }
    func getNonce(){
        Alamofire.request(serverIP + "/nonce?token=\(user.token)", encoding: JSONEncoding.default).responseJSON { (response:DataResponse<Any>) in
            if response.result.isSuccess {
                self.nonce = response.result.value as! Int
                print(self.nonce)
                self.signTransaction()
            }
            else{
                let alertController = UIAlertController(title: "網路連線錯誤\n", message: "", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    /*func getAddress(){
        Alamofire.request(serverIP + "/user?ID=\(account)&token=\(user.token)", encoding: JSONEncoding.default).responseJSON { (response:DataResponse<Any>) in
            if response.result.isSuccess {
                if let toUserResult = response.result.value as? [String: Any]{
                    if let toUser = toUserResult["inf"] as? [String: Any]{
                        self.toAddress = toUser["address"] as! String
                        self.toAddress = self.toAddress?.lowercased()
                        let index = self.toAddress!.index(self.toAddress!.startIndex, offsetBy: 2)
                        self.toAddress = String(self.toAddress![index...])
                        
                    }
                }
                if((response.result.value as! [String: Any])["type"] as! Bool == false){
                    self.dismiss(animated: true, completion: nil)

                    let alertController = UIAlertController(title: "轉出帳號錯誤\n", message: "請輸入正確的ID", preferredStyle: UIAlertController.Style.alert)
                    alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
            else{
                self.dismiss(animated: true, completion: nil)

                let alertController = UIAlertController(title: "轉出帳號錯誤\n", message: "請輸入正確的ID", preferredStyle: UIAlertController.Style.alert)
                alertController.addAction(UIAlertAction(title: "確認", style: UIAlertAction.Style.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }*/
    
    func hexToString(data: Data) -> String {
        return data.withUnsafeBytes({ (bytes: UnsafePointer<UInt8>) -> String in
            let buffer = UnsafeBufferPointer(start: bytes, count: data.count)
            return buffer.map{String(format: "%02hhx", $0)}.reduce("", {$0 + $1})
        })
    }
    
    func dataWithHexString(hex: String) -> Data {
        var hex = hex
        var data = Data()
        while(hex.count > 0) {
            let subIndex = hex.index(hex.startIndex, offsetBy: 2)
            let c = String(hex[..<subIndex])
            hex = String(hex[subIndex...])
            var ch: UInt32 = 0
            Scanner(string: c).scanHexInt32(&ch)
            var char = UInt8(ch)
            data.append(&char, count: 1)
        }
        return data
    }
    
    func signTransaction(){
        let currentTransferValue = totalTransferValue// transfer value you in current point
        let hold = dataWithHexString(hex: "a9059cbb000000000000000000000000" + self.toAddress! + String(format: "%064x", currentTransferValue))
        var transaction = EthereumTransaction(nonce: BigUInt(self.nonce + transferCount),
                                              gasPrice: BigUInt(0),
                                              gasLimit: BigUInt(4000000),
                                              to: EthereumAddress(user.address)!,
                                              value: BigUInt(0),
                                              
                                              data: hold,
                                              v: BigUInt(0),
                                              r: BigUInt(0),
                                              s: BigUInt(0))
        transaction.UNSAFE_setChainID(BigUInt(123))
        print(transaction.description)
        
        print("after")

        if let result = try?
            Web3Signer.signTX(transaction: &transaction, keystore: keystoreManager!, account: (keystoreManager!.addresses?.first!)!, password: passwordReceive!.md5() ){
            print(transaction.description)
            let msgHash = transaction.txhash
            let encoded = transaction.encode(forSignature: false, chainID: BigUInt(123))!.toHexString()
            let encodedStr = "0x" + encoded
            print(encodedStr)
            //post to server
            let params = ["mHash" : msgHash as Any, "signTx" : encodedStr, "email" : account, "number" : String(currentTransferValue), "sponser": false] as [String : Any]
            Alamofire.request(serverIP + "/transaction", method: .post, parameters: params, encoding: JSONEncoding.default, headers: header).responseJSON { (response) in
                
                if response.result.isSuccess {
                    print(response.result.value)
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    if let transactionResult: NSDictionary = (response.result.value as! NSDictionary) {
                    //if let result = response.data, let signUpResult = try?decoder.decode(TransferResult.self, from: result) {
                        print(transactionResult["status"])
                        if(transactionResult["status"] as! Int == 0){
                            let alertController = UIAlertController(title: "交易失敗\n", message: transactionResult["info"] as! String, preferredStyle: UIAlertController.Style.alert)
                            let action = UIAlertAction(title: "確認", style: UIAlertAction.Style.default){ (_) in
                                self.delegate?.dismissAndUpdateTotalPoint(update: totalPoint)
                                
                            }
                            alertController.addAction(action)
                            self.present(alertController, animated: true, completion: nil)
                        }
                        else if(transactionResult["status"] as! Int == 1){
                            let alertController = UIAlertController(title: "交易已送出\n", message: "可於交易結果查詢", preferredStyle: UIAlertController.Style.alert)
                            let transactionSend = UIAlertAction(title: "我知道了", style: UIAlertAction.Style.default){(_) in
                                self.updateTotalPoint()
                            }
                            alertController.addAction(transactionSend)
                            self.present(alertController, animated: true, completion: nil)
                        }
                    }
                    //self.performSegue(withIdentifier: "afterTransfer", sender: nil)
                }
                else{
                    let alertController = UIAlertController(title: "網路連線錯誤\n", message: "", preferredStyle: UIAlertController.Style.alert)
                    let action = UIAlertAction(title: "確認", style: UIAlertAction.Style.default){ (_) in
                        self.delegate?.dismissAndUpdateTotalPoint(update: totalPoint)
                        
                    }
                    alertController.addAction(action)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
        }
            /*
        else{
            print("failed")
            
            let alertController = UIAlertController(title: "私鑰錯誤\n", message: "請確認已在此裝置上綁定私鑰", preferredStyle: UIAlertController.Style.alert)
            let action = UIAlertAction(title: "確認", style: UIAlertAction.Style.default){ (_) in
                self.delegate?.dismissAndUpdateTotalPoint(update: totalPoint)
            }
            alertController.addAction(action)
            self.present(alertController, animated: true, completion: nil)
 
        }
        */
    }
    func updateTotalPoint(){
        Alamofire.request(serverIP + "/points", encoding: JSONEncoding.default, headers: header!).responseJSON { (response:DataResponse<Any>) in
            if response.result.isSuccess {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                print(response.result.value)
                if let result = response.data, let pointsResult = try?decoder.decode(PointsResult.self, from: result) {
                    if(pointsResult.status){
                        totalPoint = pointsResult.points
                        self.delegate?.dismissAndUpdateTotalPoint(update: pointsResult.points)

                    }
                    else{
                        totalPoint = pointsResult.points
                        self.delegate?.dismissAndUpdateTotalPoint(update: pointsResult.points)
                    }
                }
            }
            else{
                let alertController = UIAlertController(title: "網路連線錯誤\n", message: "", preferredStyle: UIAlertController.Style.alert)
                let action = UIAlertAction(title: "確認", style: UIAlertAction.Style.default){ (_) in
                    self.delegate?.dismissAndUpdateTotalPoint(update: totalPoint)

                }
                alertController.addAction(action)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    @objc func onDismiss(){
        dismiss(animated: true, completion: nil)
    }
}
extension TransferAmountController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return QRScannerAnimationController(animationDuration: 0.5, animationType: .present)
    }
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return QRScannerAnimationController(animationDuration: 0.5, animationType: .dismiss)
    }
}
extension TransferAmountController : DismissBackDelegate {
    func dismissBack(pwd: String, cancel: Bool){
        passwordReceive = pwd
        cancelReceive = cancel
        print(passwordReceive)
        //暫時註解，測試交易
        signTransaction()
        //getNonce()
    }
}
