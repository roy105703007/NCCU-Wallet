//
//  merchantSwitcher.swift
//  token
//
//  Created by 王瀚 on 2019/7/28.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class MerchantSwitcher:UICollectionView, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    var dataSet = [String]()
    var selected = Set<String>()
    init() {
        let listLayout = UICollectionViewFlowLayout()
        listLayout.minimumLineSpacing = gutter.width
        listLayout.scrollDirection = .horizontal
        super.init(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: 30), collectionViewLayout: listLayout)
        backgroundColor = .clear
        bounces = false
        clipsToBounds = false
        showsHorizontalScrollIndicator = false
        allowsSelection = true
        allowsMultipleSelection = true
        contentInset = UIEdgeInsets(top: 0, left: CGFloat(viewLeftLine), bottom: 0, right: gutter.width)
        register(MerchantSwitcherCell.self, forCellWithReuseIdentifier: "msCell")
        delegate = self
        dataSource = self
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.dataSet.count
    }
    
    func collectionView(_: UICollectionView, layout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let tempLabel = UILabel()
        tempLabel.text = dataSet[indexPath.row]
        tempLabel.font = .norm
        tempLabel.textColor = .main
        tempLabel.sizeToFit()
        return CGSize(width: tempLabel.frame.size.width + gutter.width * 2, height: 30)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cel = collectionView.dequeueReusableCell(withReuseIdentifier: "msCell", for: indexPath) as! MerchantSwitcherCell
        cel.itemTitle.text = dataSet[indexPath.row]
        if(selected.contains(dataSet[indexPath.row])){
            cel.itemTitle.layer.backgroundColor = UIColor.main.cgColor
            cel.itemTitle.textColor = .invertMain
            collectionView.selectItem(at: indexPath, animated: false, scrollPosition: UICollectionView.ScrollPosition.left)
        }
        return cel
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selected.insert(dataSet[indexPath.row])
        let cel = collectionView.cellForItem(at: indexPath) as! MerchantSwitcherCell
        cel.itemTitle.layer.backgroundColor = UIColor.main.cgColor
        cel.itemTitle.textColor = .invertMain
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        print(indexPath.row)
        let cel = collectionView.cellForItem(at: indexPath) as! MerchantSwitcherCell
        cel.itemTitle.layer.backgroundColor = UIColor.clear.cgColor
        cel.itemTitle.textColor = .main
        selected.remove(dataSet[indexPath.row])
    }
    func getSelected() -> [String] {
        return Array(selected)
    }
}
