//
//  CouponSegmentedControl.swift
//  token
//
//  Created by 王瀚 on 2019/7/23.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class CouponSegmentedControl: UISegmentedControl, CAAnimationDelegate{
    let ovalLayerRight = CAShapeLayer()
    let ovalLayerLeft = CAShapeLayer()
    let decoLayerLeft = CAShapeLayer()
    let decoLayerRight = CAShapeLayer()
    let textLeft = UILabel(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width/2, height: 15))
    let textRight = UILabel(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width/2, height: 15))
    required init() {
        super.init(items: ["",""])
        frame = CGRect(x: 0, y: (UIDevice.hasNotch ? 173 : 161) - 55, width: fullScreenSize.width, height: 55)
        setupDeco()
        setupOval()
        setupText()
        backgroundColor = .clear
        tintColor = .clear
        selectedSegmentIndex = 0
        addTarget(self, action: #selector(onChange), for: .allEvents)
        switchTo(index: 0, first: true)
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setupText(){
        textLeft.frame.origin = CGPoint(x: 0, y: 27.5)
        textLeft.textAlignment = .center
        textLeft.text = "我的電子禮券"
        textLeft.textColor = .lightGray
        textLeft.font = .norm
        
        textRight.frame.origin = CGPoint(x: fullScreenSize.width/2, y: 27.5)
        textRight.textAlignment = .center
        textRight.text = "兌換電子禮券"
        textRight.textColor = .lightGray
        textRight.font = .norm
        
        self.addSubview(textLeft)
        self.addSubview(textRight)
    }
    func setupDeco(){
        let rect = CGRect(x: 0, y: 0, width: 21/10, height: 21/10)
        decoLayerLeft.position = CGPoint(x: fullScreenSize.width / 2 - 10.5, y: 27)
        decoLayerLeft.path = UIBezierPath(ovalIn: rect).cgPath
        decoLayerLeft.fillColor = UIColor.lightYellow.cgColor
        decoLayerLeft.bounds = rect
        decoLayerLeft.opacity = 0
        
        decoLayerRight.position = CGPoint(x: fullScreenSize.width / 2 + 20, y: 16.5)
        decoLayerRight.path = UIBezierPath(ovalIn: rect).cgPath
        decoLayerRight.fillColor = UIColor.darkRed.cgColor
        decoLayerRight.bounds = rect
        decoLayerRight.opacity = 0
        
        self.layer.insertSublayer(decoLayerLeft, at: 1)
        self.layer.insertSublayer(decoLayerRight, at: 1)
    }
    func setupOval(){
        let rect = CGRect(x: 0, y: 0, width: fullScreenSize.width/2/10, height: fullScreenSize.width/2/2/10)
        ovalLayerLeft.position = CGPoint(x: fullScreenSize.width / 4, y: frame.size.height - 6)
        ovalLayerLeft.path = UIBezierPath(ovalIn: rect).cgPath
        ovalLayerLeft.fillColor = UIColor.lightBlue.cgColor
        ovalLayerLeft.bounds = rect
        ovalLayerLeft.opacity = 0
        
        ovalLayerRight.position = CGPoint(x: fullScreenSize.width * 3 / 4, y: frame.size.height - 6)
        ovalLayerRight.path = UIBezierPath(ovalIn: rect).cgPath
        ovalLayerRight.fillColor = UIColor.main.cgColor
        ovalLayerRight.bounds = rect
        ovalLayerRight.opacity = 0
        
        self.layer.insertSublayer(ovalLayerLeft, at: 0)
        self.layer.insertSublayer(ovalLayerRight, at: 0)
    }
    @objc func onChange(sender: UISegmentedControl) {
        switchTo(index: sender.selectedSegmentIndex)
    }
    func switchTo(index: Int, first: Bool = false){
        let show = showOvalAnimateGroup()
        let hide = hideOvalAnimateGroup()
        let decoShow = showOvalAnimateGroup()
        decoShow.beginTime = CACurrentMediaTime() + 0.2
        if(index == 0){
            selectedSegmentIndex = 0
            ovalLayerLeft.add(show, forKey: "showSelectOval")
            decoLayerLeft.add(decoShow, forKey: "showSelectDeco")
            if(!first){
                ovalLayerRight.add(hide, forKey: "hideSelectOval")
                decoLayerRight.add(hide, forKey: "hideSelectDeco")
                UIView.transition(with: textRight, duration: 0.2, options: .transitionCrossDissolve, animations: {
                    self.textRight.textColor = .lightGray
                }, completion: nil)
            }
            UIView.transition(with: textLeft, duration: 0.2, options: .transitionCrossDissolve, animations: {
                self.textLeft.textColor = .white
            }, completion: nil)
        }else{
            selectedSegmentIndex = 1
            ovalLayerRight.add(show, forKey: "showSelectOval")
            decoLayerRight.add(decoShow, forKey: "showSelectDeco")
            ovalLayerLeft.add(hide, forKey: "hideSelectOval")
            decoLayerLeft.add(hide, forKey: "hideSelectDeco")
            UIView.transition(with: textLeft, duration: 0.2, options: .transitionCrossDissolve, animations: {
                self.textLeft.textColor = .lightGray
            }, completion: nil)
            UIView.transition(with: textRight, duration: 0.2, options: .transitionCrossDissolve, animations: {
                self.textRight.textColor = .white
            }, completion: nil)
        }
    }
    private func showOvalAnimateGroup() -> CAAnimationGroup {
        let opacityAnim = CABasicAnimation(keyPath: "opacity")
        opacityAnim.fromValue = NSNumber(value: 0)
        opacityAnim.toValue = NSNumber(value: 1)
        
        let scaleAnim = CABasicAnimation(keyPath: "transform")
        scaleAnim.fromValue = NSValue(caTransform3D: CATransform3DIdentity)
        scaleAnim.toValue = NSValue(caTransform3D: CATransform3DMakeScale(10, 10, 1))
        
        let group = CAAnimationGroup()
        group.animations = [opacityAnim, scaleAnim]
        group.duration = 0.2
        group.delegate = self as! CAAnimationDelegate
        group.fillMode = CAMediaTimingFillMode.both
        group.isRemovedOnCompletion = false
        return group
    }
    private func hideOvalAnimateGroup() -> CAAnimationGroup {
        let opacityAnim = CABasicAnimation(keyPath: "opacity")
        opacityAnim.fromValue = NSNumber(value: 1)
        opacityAnim.toValue = NSNumber(value: 0)
        
        let scaleAnim = CABasicAnimation(keyPath: "transform")
        scaleAnim.fromValue = NSValue(caTransform3D: CATransform3DMakeScale(10, 10, 1))
        scaleAnim.toValue = NSValue(caTransform3D: CATransform3DIdentity)
        
        let group = CAAnimationGroup()
        group.animations = [opacityAnim, scaleAnim]
        group.duration = 0.2
        group.delegate = self as! CAAnimationDelegate
        group.fillMode = CAMediaTimingFillMode.both
        group.isRemovedOnCompletion = false
        return group
    }
}
