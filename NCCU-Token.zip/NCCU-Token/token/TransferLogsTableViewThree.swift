//
//  TransferLogsTableViewThree.swift
//  token
//
//  Created by Roy on 2019/9/23.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import UIKit
class TransferLogsTableViewThree: UITableView, UITableViewDelegate, UITableViewDataSource{
    struct logData{
        var opened = Bool()
        var date = String()
        var type = String()
        var amount = Int()
        var account = String()
        var title = String()
        var note = String()
        var balance = Int()
        var getMoney = Bool()
    }
    
    /*var logs = [logData(opened: false, date: "7/26", type: "參加活動", amount: 400, account: "104703006@nccu.edu.tw", title: "體重測量計畫", note: "完成第一次測量目標", balance: 8500),logData(opened: false, date: "7/27", type: "參加活動-1", amount: 1401, account: "104703006@nccu.edu.tw", title: "體重測量計畫-2", note: "完成第一次測量目標-2", balance: 8501),logData(opened: false, date: "7/28", type: "參加活動-2", amount: 1402, account: "104703006@nccu.edu.tw", title: "體重測量計畫-3", note: "完成第一次測量目標-3", balance: 8502)]*/
    
    var logs = [logData(opened: false, date: "7/26", type: "參加活動", amount: 400, account: "104703006@nccu.edu.tw", title: "體重測量計畫", note: "完成第一次測量目標", balance: 8500, getMoney: true)]
    
    let cellHeight = 37
    let itemHeight = 55
    let iconGutter = 6
    let iconSize = 32
    let iconShift = 44
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: Int(fullScreenSize.width), height: 1000), style: .plain)
        getInfo()
        self.rowHeight = CGFloat(cellHeight * 4) + gutter.height
        self.sectionHeaderHeight = CGFloat(itemHeight)
        self.register(UITableViewCell.self, forCellReuseIdentifier: "sectionCell")
        self.delegate = self
        self.dataSource = self
        self.backgroundColor = .invertMain
        self.separatorStyle = .none
        
        self.estimatedRowHeight = 0;
        self.estimatedSectionHeaderHeight = 0;
        self.estimatedSectionFooterHeight = 0;
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return logs.count + 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return (section == 0) ? CGFloat(itemHeight) + between.height + 15 + gutter.height : CGFloat(itemHeight)
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (section == 0 ) ? 0 : (logs[section - 1].opened ? 1 : 0)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = UIView(frame: CGRect(x: 0, y: 0, width: Int(fullScreenSize.width), height: itemHeight))
        header.backgroundColor = .white
        if(section == 0){
            let shift = Int(between.height + 15 + gutter.height)
            let refreshDate = UILabel(frame: CGRect(x: CGFloat(viewLeftLine), y: between.height, width: fullViewSize.width, height: 15))
            refreshDate.font = .norm
            refreshDate.textColor = .gray
            refreshDate.text = "更新時間： " + getUpdateDate()
            refreshDate.textAlignment = .right
            header.addSubview(refreshDate)
            
            let dateHint = UILabel(frame: CGRect(x: viewLeftLine, y: (itemHeight - 15) / 2 + shift, width: 56, height: 15))
            dateHint.font = .norm
            dateHint.textColor = .main
            dateHint.text = "日期"
            header.addSubview(dateHint)
            
            let typeHint = UILabel(frame: CGRect(x: viewLeftLine + Int(dateHint.frame.width), y: (itemHeight - 15) / 2 + shift, width: 150, height: 15))
            typeHint.font = .norm
            typeHint.textColor = .main
            typeHint.text = "摘要"
            header.addSubview(typeHint)
            
            let amountHint = UILabel(frame: CGRect(x: viewLeftLine + Int(typeHint.frame.width), y: (itemHeight - 15) / 2 + shift, width: 56, height: 15))
            amountHint.font = .norm
            amountHint.textColor = .main
            amountHint.text = "支出/存入"
            amountHint.sizeToFit()
            amountHint.frame.origin = CGPoint(x: fullScreenSize.width - CGFloat(iconShift) -  amountHint.frame.width, y: CGFloat(itemHeight - 15) / 2 + CGFloat(shift) )
            header.addSubview(amountHint)
            
        }else{
            let dateLabel = UILabel(frame: CGRect(x: viewLeftLine, y: (itemHeight - 15) / 2, width: 56, height: 15))
            dateLabel.font = .norm
            dateLabel.textColor = .main
            dateLabel.text = logs[section - 1].date
            header.addSubview(dateLabel)
            
            let typeLabel = UILabel(frame: CGRect(x: viewLeftLine + Int(dateLabel.frame.width), y: (itemHeight - 15) / 2, width: 150, height: 15))
            typeLabel.font = .norm
            typeLabel.textColor = .main
            typeLabel.text = logs[section - 1].type
            header.addSubview(typeLabel)
            
            let amountLabel = UILabel(frame: CGRect(x: viewLeftLine + Int(typeLabel.frame.width), y: (itemHeight - 15) / 2, width: 50, height: 15))
            amountLabel.font = .norm
            amountLabel.textColor = .main
            amountLabel.text = (logs[section - 1].getMoney ? "+ " : "- ") + moneyToString(logs[section - 1].amount) + " pt"
            amountLabel.sizeToFit()
            amountLabel.frame.origin = CGPoint(x: fullScreenSize.width - CGFloat(iconShift) - amountLabel.frame.width, y: CGFloat(itemHeight - 15) / 2 )
            header.addSubview(amountLabel)
            
            let expandBtn = UIButton(frame: CGRect(x: fullScreenSize.width - CGFloat(iconGutter) - CGFloat(iconSize), y: CGFloat(itemHeight - iconSize) / 2, width: CGFloat(iconSize), height: CGFloat(iconSize)))
            expandBtn.backgroundColor = .clear
            expandBtn.setImage(UIImage(named: "expandIcon"), for: .normal)
            expandBtn.tag = section - 1
            expandBtn.addTarget(self, action: #selector(toggleExpand), for: .touchUpInside)
            header.addSubview(expandBtn)
            
            if(section == 1){
                let  path = UIBezierPath()
                let  p0 = CGPoint(x: 0, y: 0)
                path.move(to: p0)
                let  p1 = CGPoint(x: fullScreenSize.width, y: 0)
                path.addLine(to: p1)
                let dashLine = CAShapeLayer()
                dashLine.strokeColor = UIColor.lightBlue.cgColor
                dashLine.lineWidth = 2
                dashLine.lineDashPattern = [4, 4]
                dashLine.fillColor = nil
                dashLine.path = path.cgPath
                dashLine.rasterizationScale = UIScreen.main.scale;
                dashLine.shouldRasterize = true;
                header.layer.addSublayer(dashLine)
            }else{
                let  path = UIBezierPath()
                let  p0 = CGPoint(x: 0, y: 0)
                path.move(to: p0)
                let  p1 = CGPoint(x: fullScreenSize.width, y:0)
                path.addLine(to: p1)
                let dashLine = CAShapeLayer()
                dashLine.strokeColor = UIColor.main.cgColor
                dashLine.lineWidth = 1
                dashLine.lineDashPattern = [4, 4]
                dashLine.fillColor = nil
                dashLine.path = path.cgPath
                dashLine.rasterizationScale = UIScreen.main.scale;
                dashLine.shouldRasterize = true;
                header.layer.addSublayer(dashLine)
            }
        }
        
        return header
    }
    
    @objc func toggleExpand(sender:UIButton){
        if(logs[sender.tag].opened){
            for ind in logs.indices{
                if(logs[ind].opened){
                    logs[ind].opened = false
                    self.beginUpdates()
                    self.reloadSections(IndexSet.init(integer: ind+1), with: .none)
                    self.endUpdates()
                }
            }
        }else{
            for ind in logs.indices{
                let status = (ind == sender.tag) ? true : false
                if(logs[ind].opened != status){
                    logs[ind].opened = status
                    self.beginUpdates()
                    self.reloadSections(IndexSet.init(integer: ind+1), with: .none)
                    self.endUpdates()
                }
            }
        }
        self.layoutIfNeeded()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath as IndexPath)
        cell.subviews.forEach({ $0.removeFromSuperview() })
        print(indexPath.section - 1)
        cell.clipsToBounds = true
        cell.frame.size = CGSize(width: fullScreenSize.width, height: CGFloat(cellHeight*4) + gutter.height)
        // 設置 Accessory 按鈕樣式
        cell.backgroundColor = .invertMain
        if(indexPath.section != 0){
            let section = indexPath.section - 1
            let accountHint = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2, width: 100, height: 15))
            accountHint.font = .normBold
            accountHint.textColor = .main
            accountHint.text = "發款/收款人"
            cell.addSubview(accountHint)
            
            let accountLabel = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2, width: 100, height: 15))
            accountLabel.font = .norm
            accountLabel.textColor = .main
            accountLabel.text = logs[section].account
            accountLabel.sizeToFit()
            accountLabel.frame.origin = CGPoint(x: fullScreenSize.width - CGFloat(iconShift) - accountLabel.frame.width, y:CGFloat(cellHeight - 15) / 2)
            cell.addSubview(accountLabel)
            
            let titleHint = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2 + cellHeight, width: 100, height: 15))
            titleHint.font = .normBold
            titleHint.textColor = .main
            titleHint.text = "名目"
            cell.addSubview(titleHint)
            
            let titleLabel = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2 + cellHeight, width: 100, height: 15))
            titleLabel.font = .norm
            titleLabel.textColor = .main
            titleLabel.text = logs[section].title
            titleLabel.sizeToFit()
            titleLabel.frame.origin = CGPoint(x: fullScreenSize.width - CGFloat(iconShift) - titleLabel.frame.width, y:CGFloat(cellHeight - 15) / 2 + CGFloat(cellHeight))
            cell.addSubview(titleLabel)
            
            let noteHint = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2 + cellHeight*2, width: 100, height: 15))
            noteHint.font = .normBold
            noteHint.textColor = .main
            noteHint.text = "備註"
            cell.addSubview(noteHint)
            
            let noteLabel = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2 + cellHeight*2, width: 100, height: 15))
            noteLabel.font = .norm
            noteLabel.textColor = .main
            noteLabel.text = logs[section].note
            noteLabel.sizeToFit()
            noteLabel.frame.origin = CGPoint(x: fullScreenSize.width - CGFloat(iconShift) - noteLabel.frame.width, y: CGFloat(cellHeight-15) / 2 + CGFloat(cellHeight*2))
            cell.addSubview(noteLabel)
            
            let balanceHint = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2 + cellHeight*3, width: 100, height: 15))
            balanceHint.font = .normBold
            balanceHint.textColor = .lightBlue
            balanceHint.text = "結餘"
            cell.addSubview(balanceHint)
            
            let balanceLabel = UILabel(frame: CGRect(x: viewLeftLine, y: (cellHeight - 15) / 2 + cellHeight*3, width: 100, height: 15))
            balanceLabel.font = .norm
            balanceLabel.textColor = .lightBlue
            balanceLabel.text = moneyToString(logs[section].balance)
            balanceLabel.sizeToFit()
            balanceLabel.frame.origin = CGPoint(x: fullScreenSize.width - CGFloat(iconShift) - balanceLabel.frame.width, y:CGFloat(cellHeight - 15) / 2 + CGFloat(cellHeight*3))
            cell.addSubview(balanceLabel)
        }
        
        return cell
    }
    
    func getInfo(){
        var nowDate = Date()
        var preBalance: Int = totalPoint
        self.logs = []
        for i in logResults?.tx_logs ?? []{
            if stringConvertDate(string: i.create_date) < nowDate-60*60*24*30 {
                continue
            }
            var tempDate : Date
            tempDate = stringConvertDate(string: i.create_date)
            let dateformatter = DateFormatter()
            dateformatter.dateFormat = "MM/dd"
            let dateString = dateformatter.string(from: tempDate)
            if i.from_account.name == user.name{
                logs.append(logData(opened: false, date: dateString, type: i.description, amount: i.point, account: i.to_account.name, title: i.description , note: i.status, balance: preBalance, getMoney: false))
                preBalance += i.point
            }
            else {
                logs.append(logData(opened: false, date: dateString, type: i.description, amount: i.point, account: i.from_account.name, title: i.description, note: i.status, balance: preBalance, getMoney: true))
                preBalance -= i.point
            }
        }
        self.reloadData()
    }
    
    func getUpdateDate() -> String {
        var tempDate : Date
        tempDate = stringConvertDate(string: logResults?.tx_logs[0].create_date ?? "")
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy/MM/dd HH:mm:ss"
        let dateString = dateformatter.string(from: tempDate)
        return dateString
        //return "2019/09/26 00:12:36"
    }
}
