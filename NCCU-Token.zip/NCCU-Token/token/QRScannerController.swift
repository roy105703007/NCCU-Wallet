//
//  QRScannerController.swift
//  token
//
//  Created by 王瀚 on 2019/7/29.
//  Copyright © 2019 徐胤桓. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit
class QRScannerController: UIViewController{
    var captureSession = AVCaptureSession()
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var scanRect: UIView?
    var delegate: GetAccountId?
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera], mediaType: AVMediaType.video, position: .back)
        
        guard let captureDevice = deviceDiscoverySession.devices.first else {
            print("Failed to get the camera device")
            return
        }
        
        do {
            let input = try AVCaptureDeviceInput(device: captureDevice)
            captureSession.addInput(input)
            let captureMetadataOutput = AVCaptureMetadataOutput()
            captureSession.addOutput(captureMetadataOutput)
            captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            captureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
            videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            videoPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
            videoPreviewLayer?.frame = view.layer.bounds
            view.layer.addSublayer(videoPreviewLayer!)
            captureSession.startRunning()
            
            let dimCover = UIView(frame: CGRect(x: 0, y: 0, width: fullScreenSize.width, height: fullScreenSize.height))
            dimCover.backgroundColor = .black
            dimCover.backgroundColor = UIColor.black.withAlphaComponent(0.77)
            
            let backButton = UIButton(frame: CGRect(x: 0, y: statusBarHeight, width: 188, height: 44))
            backButton.backgroundColor = .clear
            backButton.setImage(UIImage(named: "backIcon")?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate), for: .normal)
            backButton.setTitle(lang["back"], for: .normal)
            backButton.setTitleColor(.white, for: .normal)
            backButton.tintColor = .white
            backButton.contentMode = .left
            backButton.imageView?.contentMode = .scaleAspectFit
            backButton.contentHorizontalAlignment = .left
            backButton.imageEdgeInsets = UIEdgeInsets(top: 12, left: 0, bottom: 12, right: -5)
            backButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: -8, bottom: 0, right: 0)
            backButton.addTarget(self, action: #selector(self.onDismiss), for: .touchUpInside)
            
            let mask = CAShapeLayer()
            var path = UIBezierPath()
            mask.fillColor = UIColor.black.cgColor
            path.move(to: CGPoint(x: (fullScreenSize.width - 300) / 2, y: backButton.frame.origin.y + backButton.frame.height + 115))
            path.addLine(to: CGPoint(x: fullScreenSize.width - (fullScreenSize.width - 300) / 2, y: backButton.frame.origin.y + backButton.frame.height + 115))
            path.addLine(to: CGPoint(x: fullScreenSize.width - (fullScreenSize.width - 300) / 2, y: backButton.frame.origin.y + backButton.frame.height + 415))
            path.addLine(to: CGPoint(x: (fullScreenSize.width - 300) / 2, y: backButton.frame.origin.y + backButton.frame.height + 415))
            path.addLine(to: CGPoint(x: (fullScreenSize.width - 300) / 2, y: backButton.frame.origin.y + backButton.frame.height + 115))
            path.close()
            path.append(UIBezierPath(rect: self.view.bounds))
            mask.path = path.cgPath
            mask.fillRule = CAShapeLayerFillRule.evenOdd
            dimCover.layer.mask = mask
            view.addSubview(dimCover)
            
            view.addSubview(backButton)
            
            scanRect = UIView(frame: CGRect(x: (fullScreenSize.width - 300) / 2 - 3, y: backButton.frame.origin.y + backButton.frame.height + 112, width: 306, height: 306))
            scanRect!.addDashBorder(color: UIColor.lightBlue, width: 5, dash: [20,20])
            view.addSubview(scanRect!)
            
            let scanTitle = UILabel(frame: CGRect(x: 0, y: backButton.frame.origin.y + backButton.frame.height + between.height, width: fullScreenSize.width, height: 22))
            scanTitle.textColor = .white
            scanTitle.font = .bigBold
            scanTitle.textAlignment = .center
            scanTitle.text = lang["scanTitle"]
            view.addSubview(scanTitle)
            
            let scanTitleHint = UILabel(frame: CGRect(x: 0, y: scanRect!.frame.origin.y + scanRect!.frame.height + between.height, width: fullScreenSize.width, height: 20))
            scanTitleHint.textColor = .white
            scanTitleHint.font = .norm
            scanTitleHint.textAlignment = .center
            scanTitleHint.text = lang["scanTitleHint"]
            view.addSubview(scanTitleHint)
            
        } catch {
            // 假如有錯誤產生、單純輸出其狀況不再繼續執行
            print(error)
            return
        }
    }
    
    @objc func onDismiss(){
        dismiss(animated: true, completion: nil)
    }
}
extension QRScannerController: AVCaptureMetadataOutputObjectsDelegate {
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        // 檢查  metadataObjects 陣列為非空值，它至少需包含一個物件
        if metadataObjects.count == 0 {
            print("nothing")
            return
        }
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        if metadataObj.type == AVMetadataObject.ObjectType.qr {
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            if metadataObj.stringValue != nil {
                print(metadataObj.stringValue)
                delegate?.getAccountIdToTransfer(sentData: metadataObj.stringValue ?? "test qrcode")
                dismiss(animated: true, completion: nil)
            }
        }
    }
}

extension QRScannerController: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return QRScannerAnimationController(animationDuration: 0.5, animationType: .present)
    }
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return QRScannerAnimationController(animationDuration: 0.5, animationType: .dismiss)
    }
}
